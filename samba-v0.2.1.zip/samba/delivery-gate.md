# Delivery Gate: SAMBA 0.2.1

antislop aktif: DURING (diminta pemilik: desain ulang dengan antislop).
Design Read: Membaca ini sebagai: aplikasi utilitas Android untuk pengguna yang suka menyesuaikan ponsel, bergaya minimalis hitam dengan satu aksen oranye, dial ENERGY 2 / RHYTHM 2 / MOTION 2.
Arah: DESIGN.md, bersumber dari dokumen konsep dan gambar contoh 'Island: enam kondisi'.

STATUS: 49 PASS, 1 FAIL. Belum boleh dianggap final: R-35 gagal karena aplikasi belum pernah dibangun atau dijalankan. Diserahkan sebagai kandidat build.
Keterangan: [kode] berarti dibuktikan dari kode sumber, belum dari perangkat. [dihitung] berarti hasil skrip pemeriksa.

## Blok 1: Hard Gate
- R-02 PASS: tidak ada karakter em dash (U+2014) di 22 file teks proyek (hitungan: 0)
- R-03 PASS: [kode] tanpa lebar tetap: island memakai min(lebar layar - 24, 320) dp; teks panjang dipotong titik-titik; halaman bisa digulir; area sentuh: island 44, transport 48, segmen 44, baris 56, tab 56 dp. Uji layar fisik masuk R-35
- R-17 PASS: tidak ada angka karangan. Angka yang tampil: persen baterai dan jumlah aplikasi terpilih (data nyata), progres pratinjau diberi keterangan data contoh
- R-18 PASS: tidak ada testimoni, avatar, atau nama orang. Pratinjau memakai teks 'Contoh pengirim'
- R-23 PASS: logo tetap dari dokumen konsep (tidak dibuat ulang). Tile aplikasi dan cover memakai pengganti jujur: huruf pertama atau kotak polos
- R-24 PASS: navigasi bawah punya 4 tujuan yang semuanya ada (Home, Customize, Notifications, Settings). Themes tidak dipajang karena belum dibuat
- R-25 PASS: [dihitung] 12 pasangan warna memenuhi batas; terendah 3.83:1 (Accent di Ink)
- R-26 PASS: [kode] tiap kontrol punya aksi: tab ganti halaman, segmen ganti pratinjau, toggle Island menyalakan atau mematikan layanan, tombol izin membuka pengaturan sistem, sakelar dan slider mengubah SambaStore, 'Kirim notifikasi uji' memicu island (nonaktif dengan penjelasan saat Island mati), tombol transport memanggil MediaController
- R-27 PASS: daftar aplikasi punya Memuat (spinner + teks), Kosong (penjelasan), Gagal (tombol Coba lagi); island tanpa media kembali ke Compact; baterai tidak terbaca tampil '--'
- R-28 PASS: tidak ada FAQ
- R-32 PASS: [kode] layar aplikasi memakai clickable, toggleable, dan selectable dengan peran semantik (Switch, Tab, Button), jadi bisa dijangkau papan ketik dan pembaca layar. Catatan platform: overlay sengaja tidak menerima fokus papan ketik (agar tidak mencuri input aplikasi di depan), kontrolnya tetap punya label untuk pembaca layar
- R-33 PASS: semua fitur ditulis langsung di source; tidak ada skrip .py/.sh/.js di repositori (hitungan: 0)
- R-34 PASS: tidak ada toggle tema; satu tema gelap dengan alasan di R-21
- R-35 FAIL: BELUM DIJALANKAN. Sandbox tanpa Android SDK dan internet (hanya JRE, tanpa kotlinc/gradle), jadi aplikasi belum pernah dibangun atau dicoba. Yang sudah diperiksa: XML valid, YAML valid, kurung kode seimbang, pencarian pola, hitung kontras. Build lewat GitHub Actions dan uji di ponsel diperlukan
- R-36 PASS: klaim privasi bisa dicek: manifest tidak memuat izin INTERNET (hitungan: 0). Tidak ada klaim performa atau kepatuhan
- R-37 PASS: arah memakai DESIGN.md yang dipindahkan dari dokumen konsep dan gambar contoh milik pemilik produk; warna diambil dari piksel gambar
- R-38 PASS: semua konten nyata atau berlabel: pratinjau memakai 'Contoh ...' dan keterangan 'Pratinjau dengan data contoh'

## Blok 2: Purpose-Gate
- R-01 PASS: tidak ada gradasi di kode (hitungan Gradient/Brush: 0). Warna: hitam #000000 dan satu aksen oranye #F0561F
- R-04 PASS: tidak ada ikon generik (sparkle, bolt, dan sejenisnya: 0). Ikon baterai dan transport digambar dari bentuk dasar karena menandai fungsi
- R-06 PASS: huruf sans bawaan sistem: tanpa unduhan font, terasa asli di dalam Android. Spasi huruf lebar hanya untuk wordmark SAMBA (di Peek dan Home), sesuai gambar contoh
- R-07 PASS: tidak ada latar kisi atau pola
- R-08 PASS: tidak ada panah dekoratif (hitungan: 0)
- R-09 PASS: tidak ada badge kapsul
- R-10 PASS: tidak ada blur atau kaca (diperiksa bersama R-01)
- R-12 PASS: tidak ada bayangan atau elevasi; kedalaman dibuat dari hitam di atas krem
- R-13 PASS: tidak ada glow
- R-14 PASS: tidak ada kartu fitur. Satu panel peringatan izin, selebihnya baris datar
- R-19 PASS: gerak punya fungsi: island berubah ukuran (spring) menandai kondisi baru, crossfade mengganti isi, gelombang audio hanya bergerak saat lagu diputar, progres hanya diperbarui saat MusicOpen terbuka, pindah halaman memudar 140 ms. Tidak ada animasi hiasan
- R-22 PASS: tidak ada ilustrasi

## Blok 3: Liveliness
- Dial PASS: ENERGY 2 / RHYTHM 2 / MOTION 2 tertulis di DESIGN.md
- Konsisten dengan dial PASS: MOTION 2: ada transisi bermakna, tanpa koreografi. RHYTHM 2: panel pratinjau krem menjadi jeda di antara baris datar
- Satu fokus per layar PASS: Home: pratinjau island. Customize: pratinjau ukuran. Notifications: pemberitahuan akses atau daftar aplikasi. Settings: status izin
- Ruang kosong terstruktur PASS: jarak 24 dp antar kelompok besar, 12 dp di dalam kelompok, pemisah garis tipis antar bagian
- Satu aksen PASS: oranye #F0561F saja: gelombang, isi baterai, progres, tombol utama, status aktif, penanda tab
- Motif identitas PASS: pil hitam yang berubah bentuk; wordmark SAMBA berspasi lebar
- Design Read dideklarasikan PASS: Membaca ini sebagai: aplikasi utilitas Android untuk pengguna yang suka menyesuaikan ponsel, bergaya minimalis hitam dengan satu aksen oranye, dial ENERGY 2 / RHYTHM 2 / MOTION 2

## Blok 4: Craftsmanship dan Quality Locks
- C-1 PASS: tiap keputusan punya alasan satu baris (daftar di bawah)
- C-2 PASS: tidak ada kontrol mati (lihat R-26)
- C-3 PASS: tidak ada bagian pengisi template; tiap layar ada karena fungsinya
- C-4 PASS: [kode] keadaan memuat, kosong, gagal ditangani; satu tema gelap; kontrol bisa dijangkau pembaca layar. Uji breakpoint dan perangkat masuk R-35
- C-5 PASS: tidak ada klaim karangan (lihat R-17, R-18, R-36)
- R-05 PASS: tidak memakai tata letak template web; tiap halaman disusun dari isinya
- R-11 PASS: hanya island yang berbentuk pil (bentuk produk). Radius lain: 10.dp, 12.dp, 24.dp, 8.dp, boxSize * 0.23f, corner, minOf(h / 2, 34.dp
- R-15 PASS: CTA spesifik: Aktifkan izin, Beri akses notifikasi, Kirim notifikasi uji, Coba lagi (CTA generik: 0)
- R-16 PASS: tidak ada kata buzzword (hitungan: 0)
- R-20 PASS: ditukar logonya pun tetap khas: bentuk pil hitam yang berubah, satu aksen oranye, enam kondisi berpola tetap
- R-21 PASS: tema gelap tetap punya alasan: island hitam OLED harus menyatu dengan lubang kamera dan dokumen konsep meminta hitam pekat; panel pratinjau krem memperlihatkan island di latar terang
- R-29 PASS: satu aksen (oranye) di atas netral hitam, putih, krem, abu hangat
- R-30 PASS: tidak meniru produk lain; rujukan visual adalah gambar contoh pemilik produk
- R-31 PASS: alasan keputusan tertulis di bawah

## Kontras warna (dihitung dari nilai di IslandOverlay.kt)
- TextPrimary di atas Ink, teks utama di aplikasi: 19.90:1 (minimum 4.5) PASS
- Muted di atas Ink, teks sekunder di aplikasi: 9.11:1 (minimum 4.5) PASS
- TextPrimary di atas Surface, teks di panel dan segmen tidak terpilih: 17.56:1 (minimum 4.5) PASS
- Muted di atas Surface, teks sekunder di panel: 8.04:1 (minimum 4.5) PASS
- TextPrimary di atas Black, teks utama di island: 21.00:1 (minimum 4.5) PASS
- Muted di atas Black, teks sekunder di island: 9.61:1 (minimum 4.5) PASS
- Accent di atas Ink, status Aktif: 5.74:1 (minimum 4.5) PASS
- Ink di atas Accent, teks tombol utama: 5.74:1 (minimum 4.5) PASS
- TextPrimary di atas Tile, segmen terpilih dan huruf pada tile: 11.88:1 (minimum 4.5) PASS
- Muted di atas Line, teks tombol nonaktif: 6.46:1 (minimum 4.5) PASS
- CreamText di atas Cream, keterangan panel pratinjau: 6.10:1 (minimum 4.5) PASS
- Accent di atas Black, isi baterai, gelombang, progres (non-teks): 6.06:1 (minimum 3.0) PASS

## Alasan keputusan (R-31)
- Warna: island #000000 agar menyatu dengan lubang kamera OLED. Oranye #F0561F satu-satunya aksen, dipakai pada sinyal hidup (gelombang, baterai, progres) dan aksi utama, sesuai gambar contoh.
- Tata letak: enam kondisi satu bentuk pil yang berubah ukuran. Notification dan MusicOpen lebih tinggi karena butuh tiga baris dan kontrol.
- Tipografi: sans bawaan sistem agar terasa asli di Android dan tanpa unduhan font. Wordmark berspasi lebar karena itu identitas, bukan label.
- Jarak: 24 dp antar kelompok besar, 12 dp di dalam kelompok. Target sentuh 44 sampai 56 dp agar mudah ditekan satu tangan.
- Kartu: tidak ada kartu fitur. Satu panel untuk peringatan izin karena perlu menonjol, selebihnya baris datar.
- Ikon dan ilustrasi: tidak ada hiasan. Ikon baterai dan transport digambar dari bentuk dasar karena menandai fungsi.

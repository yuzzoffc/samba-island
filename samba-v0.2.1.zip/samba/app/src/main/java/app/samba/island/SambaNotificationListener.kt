package app.samba.island

import android.app.KeyguardManager
import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Membaca notifikasi hanya setelah pengguna memberi akses di pengaturan sistem.
 * Hanya aplikasi yang dipilih pengguna yang diteruskan ke island, dan isinya
 * tidak disimpan di mana pun (hanya di memori sampai island menutup).
 */
class SambaNotificationListener : NotificationListenerService() {

    override fun onListenerConnected() {
        IslandBus.listenerConnected = true
    }

    override fun onListenerDisconnected() {
        IslandBus.listenerConnected = false
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        SambaStore.load(this)
        val cfg = SambaStore.config.value
        if (!cfg.enabled || !cfg.notifEnabled || !IslandBus.running) return
        if (sbn.packageName !in cfg.allowedApps) return

        val n = sbn.notification ?: return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        if ((n.flags and Notification.FLAG_ONGOING_EVENT) != 0) return
        val category = n.category
        if (category != null && category in IGNORED_CATEGORIES) return

        val locked = getSystemService(KeyguardManager::class.java)?.isKeyguardLocked == true
        if (locked && n.visibility == Notification.VISIBILITY_SECRET) return

        val extras = n.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return

        val appName = appLabel(sbn.packageName)
        val hide = locked && cfg.hideOnLock
        IslandBus.show(
            NotificationEvent(
                id = IslandBus.nextId(),
                appName = appName,
                title = if (hide) appName else title.ifBlank { appName },
                text = if (hide) "Pesan baru" else text,
                icon = AppIcons.get(this, sbn.packageName),
                intent = n.contentIntent,
            )
        )
    }

    private fun appLabel(pkg: String): String =
        try {
            val pm = packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }

    private companion object {
        val IGNORED_CATEGORIES = setOf(
            Notification.CATEGORY_TRANSPORT,
            Notification.CATEGORY_PROGRESS,
            Notification.CATEGORY_SERVICE,
            Notification.CATEGORY_SYSTEM,
            Notification.CATEGORY_STATUS,
        )
    }
}

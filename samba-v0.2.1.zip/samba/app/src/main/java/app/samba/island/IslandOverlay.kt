package app.samba.island

import android.graphics.Bitmap
import android.os.SystemClock
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

/**
 * Warna diambil dari gambar contoh "Island: enam kondisi" milik pemilik produk.
 * Black = isi island. Accent = satu-satunya aksen. Tile dan Muted = netral hangat.
 * Cream dan CreamText hanya untuk papan pratinjau. Ink = latar aplikasi dari briefing.
 */
object SambaColors {
    val Ink = Color(0xFF08090D)
    val Black = Color(0xFF000000)
    val Surface = Color(0xFF1B1914)
    val Line = Color(0xFF2E2B24)
    val Tile = Color(0xFF3A372F)
    val TextPrimary = Color(0xFFFFFFFF)
    val Muted = Color(0xFFB5AFA1)
    val Accent = Color(0xFFF0561F)
    val Cream = Color(0xFFF2EEE6)
    val CreamText = Color(0xFF5E584C)
}

/**
 * Island di dalam overlay. Dipasang oleh IslandService.
 * Prioritas: notifikasi > pengisian daya > musik > intip (Peek) > compact.
 */
@Composable
fun IslandHost() {
    val context = LocalContext.current
    val cfg by SambaStore.config.collectAsState()
    val event by IslandBus.event.collectAsState()
    val mediaRaw by IslandBus.media.collectAsState()
    var peek by remember { mutableStateOf(false) }
    var musicOpen by remember { mutableStateOf(false) }

    val media = if (cfg.musicEnabled) mediaRaw else null
    val current = event

    // Kejadian sementara hilang sendiri setelah durasinya habis.
    LaunchedEffect(current?.id) {
        val ev = current ?: return@LaunchedEffect
        val seconds = if (ev is NotificationEvent) cfg.notifSeconds else 3
        delay(seconds * 1000L)
        IslandBus.clear(ev.id)
    }
    LaunchedEffect(peek) {
        if (peek) {
            delay(4000)
            peek = false
        }
    }
    LaunchedEffect(musicOpen) {
        if (musicOpen) {
            delay(7000)
            musicOpen = false
        }
    }
    LaunchedEffect(media == null) {
        if (media == null) musicOpen = false
    }

    val mode: IslandMode = when {
        current is NotificationEvent -> IslandMode.Notification(current)
        current is ChargingEvent -> IslandMode.Charging
        media != null && musicOpen -> IslandMode.MusicOpen(media)
        media != null -> IslandMode.MusicMini(media)
        peek -> IslandMode.Peek
        else -> IslandMode.Compact
    }

    IslandView(
        mode = mode,
        cfg = cfg,
        onTap = {
            when (mode) {
                is IslandMode.Notification -> {
                    IslandBus.open(context, mode.event)
                    IslandBus.clear(mode.event.id)
                }
                IslandMode.Charging -> current?.let { IslandBus.clear(it.id) }
                is IslandMode.MusicMini -> musicOpen = true
                is IslandMode.MusicOpen -> musicOpen = false
                IslandMode.Peek -> peek = false
                IslandMode.Compact -> peek = true
            }
        },
        onPlayPause = { IslandBus.playPause() },
        onNext = { IslandBus.next() },
        onPrevious = { IslandBus.previous() },
    )
}

/** Kunci konten: berubah hanya saat jenis island atau lagu/notifikasinya berganti. */
private fun modeKey(mode: IslandMode): String =
    when (mode) {
        IslandMode.Compact -> "compact"
        IslandMode.Peek -> "peek"
        IslandMode.Charging -> "charging"
        is IslandMode.MusicMini -> "mini:" + mode.media.title
        is IslandMode.MusicOpen -> "open:" + mode.media.title
        is IslandMode.Notification -> "notif:" + mode.event.id
    }

private class ModeHolder {
    var current: IslandMode? = null
    var previous: IslandMode? = null
}

/**
 * Tampilan island yang murni presentasi (dipakai overlay dan pratinjau di aplikasi).
 * Ukuran dianimasikan dengan spring, isi berganti dengan crossfade.
 * Ukuran tiap kondisi mengikuti rasio gambar contoh (compact 120x34 dp sebagai acuan).
 */
@Composable
fun IslandView(
    mode: IslandMode,
    cfg: IslandConfig,
    modifier: Modifier = Modifier,
    fixedProgress: Float? = null,
    onTap: () -> Unit = {},
    onPlayPause: () -> Unit = {},
    onNext: () -> Unit = {},
    onPrevious: () -> Unit = {},
) {
    val screenW = LocalConfiguration.current.screenWidthDp
    val maxW = minOf(screenW - 24, 320).dp
    val compactW = cfg.width.dp
    val compactH = cfg.height.dp

    val target: Pair<Dp, Dp> = when (mode) {
        IslandMode.Compact -> compactW to compactH
        IslandMode.Peek -> (compactW + 50.dp) to compactH
        IslandMode.Charging -> (compactW + 70.dp) to compactH
        is IslandMode.MusicMini -> (compactW + 88.dp) to compactH
        is IslandMode.MusicOpen -> maxW to 148.dp
        is IslandMode.Notification -> maxW to 68.dp
    }

    val spec = spring<Dp>(dampingRatio = 0.74f, stiffness = 360f)
    val w by animateDpAsState(target.first, spec, label = "islandW")
    val h by animateDpAsState(target.second, spec, label = "islandH")
    val shape = RoundedCornerShape(minOf(h / 2, 34.dp))

    // Nama untuk pembaca layar, hanya untuk kondisi yang tidak punya teks sendiri.
    val label: String? = when (mode) {
        IslandMode.Compact -> "Island SAMBA. Ketuk untuk melihat status."
        is IslandMode.MusicMini -> "Memutar ${mode.media.title}. Ketuk untuk membuka kontrol."
        IslandMode.Charging -> "Sedang mengisi daya."
        else -> null
    }
    val labelModifier = if (label != null) {
        Modifier.semantics { contentDescription = label }
    } else {
        Modifier
    }

    // Konten lama tetap memakai datanya sendiri selama memudar.
    val holder = remember { ModeHolder() }
    val key = modeKey(mode)
    val last = holder.current
    if (last == null || modeKey(last) != key) holder.previous = last
    holder.current = mode

    // Area sentuh minimal 44dp. Pil menempel di atas, sisa area transparan ada di bawahnya.
    Box(
        modifier = modifier
            .heightIn(min = 44.dp)
            .then(labelModifier)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                role = Role.Button,
                onClick = onTap,
            ),
        contentAlignment = Alignment.TopCenter,
    ) {
        Box(
            modifier = Modifier
                .size(w, h)
                .clip(shape)
                .background(SambaColors.Black),
            contentAlignment = Alignment.Center,
        ) {
            Crossfade(
                targetState = key,
                modifier = Modifier.fillMaxSize(),
                animationSpec = tween(180),
                label = "islandContent",
            ) { k ->
                val m = if (k == key) mode else (holder.previous ?: mode)
                when (m) {
                    IslandMode.Compact -> Box(Modifier.fillMaxSize())
                    IslandMode.Peek -> PeekContent()
                    IslandMode.Charging -> ChargingContent()
                    is IslandMode.MusicMini -> MusicMiniContent(m.media, compactH)
                    is IslandMode.MusicOpen ->
                        MusicOpenContent(m.media, fixedProgress, onPlayPause, onNext, onPrevious)
                    is IslandMode.Notification -> NotificationContent(m.event)
                }
            }
        }
    }
}

/** Peek: hanya nama SAMBA. Spasi huruf lebar karena ini wordmark, bukan label biasa. */
@Composable
private fun PeekContent() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(
            "SAMBA",
            color = SambaColors.TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 2.sp,
            maxLines = 1,
        )
    }
}

/** Charging: ikon baterai di kiri, persen di kanan. */
@Composable
private fun ChargingContent() {
    val battery by IslandBus.battery.collectAsState()
    Row(
        modifier = Modifier.fillMaxSize().padding(horizontal = 13.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        BatteryGlyph(battery.level, Modifier.size(width = 19.dp, height = 10.dp))
        Text(
            if (battery.level >= 0) "${battery.level}%" else "--",
            color = SambaColors.TextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
        )
    }
}

/** MusicMini: cover di kiri, gelombang audio di kanan. */
@Composable
private fun MusicMiniContent(media: MediaInfo, height: Dp) {
    Row(
        modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AlbumArt(media.art, maxOf(height - 11.dp, 14.dp), 6.dp)
        Waveform(media.playing, Modifier.size(width = 22.dp, height = 12.dp))
    }
}

@Composable
private fun MusicOpenContent(
    media: MediaInfo,
    fixedProgress: Float?,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 15.dp, vertical = 13.dp),
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AlbumArt(media.art, 53.dp, 8.dp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    media.title,
                    color = SambaColors.TextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    media.artist,
                    color = SambaColors.Muted,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Spacer(Modifier.width(8.dp))
            Waveform(media.playing, Modifier.size(width = 22.dp, height = 13.dp))
        }
        MusicProgress(media, fixedProgress)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TransportButton(Transport.Previous, "Lagu sebelumnya", onPrevious)
            Spacer(Modifier.width(9.dp))
            TransportButton(
                if (media.playing) Transport.Pause else Transport.Play,
                if (media.playing) "Jeda" else "Putar",
                onPlayPause,
            )
            Spacer(Modifier.width(9.dp))
            TransportButton(Transport.Next, "Lagu berikutnya", onNext)
        }
    }
}

@Composable
private fun MusicProgress(media: MediaInfo, fixed: Float?) {
    val progress by IslandBus.progress.collectAsState()
    var now by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }

    // Memperbarui bilah progres hanya selama lagu diputar dan island musik terbuka.
    LaunchedEffect(media.playing, media.duration, fixed) {
        while (media.playing && fixed == null) {
            now = SystemClock.elapsedRealtime()
            delay(500)
        }
    }

    val fraction: Float = when {
        fixed != null -> fixed
        media.duration <= 0L -> 0f
        else -> {
            val position = if (media.playing) {
                progress.position + ((now - progress.updateTime) * progress.speed).toLong()
            } else {
                progress.position
            }
            (position.toFloat() / media.duration).coerceIn(0f, 1f)
        }
    }

    Box(
        Modifier
            .fillMaxWidth()
            .height(4.dp)
            .clip(CircleShape)
            .background(SambaColors.Line)
    ) {
        Box(
            Modifier
                .fillMaxWidth(fraction)
                .fillMaxHeight()
                .background(SambaColors.Accent)
        )
    }
}

/** Notification: tile aplikasi, lalu nama aplikasi, pengirim, dan isi pesan. */
@Composable
private fun NotificationContent(e: NotificationEvent) {
    Row(
        modifier = Modifier.fillMaxSize().padding(horizontal = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AppIcon(e.icon, e.appName, 42.dp)
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            if (e.title != e.appName) {
                Text(
                    e.appName,
                    color = SambaColors.Muted,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Text(
                e.title,
                color = SambaColors.TextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                e.text,
                color = SambaColors.Muted,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun AlbumArt(art: Bitmap?, boxSize: Dp, corner: Dp) {
    val shape = RoundedCornerShape(corner)
    val image = remember(art) { art?.asImageBitmap() }
    if (image != null) {
        Image(
            bitmap = image,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(boxSize).clip(shape),
        )
    } else {
        // Pengganti saat lagu tidak menyertakan sampul.
        Box(Modifier.size(boxSize).clip(shape).background(SambaColors.Tile))
    }
}

@Composable
private fun AppIcon(icon: ImageBitmap?, name: String, boxSize: Dp) {
    val shape = RoundedCornerShape(boxSize * 0.23f)
    if (icon != null) {
        Image(
            bitmap = icon,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(boxSize).clip(shape),
        )
    } else {
        // Pengganti saat ikon aplikasi tidak bisa dibaca: huruf pertama nama aplikasi.
        Box(
            Modifier.size(boxSize).clip(shape).background(SambaColors.Tile),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                name.take(1).uppercase(),
                color = SambaColors.TextPrimary,
                fontSize = (boxSize.value * 0.42f).sp,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}

/** Menandai lagu sedang diputar. Bergerak hanya saat memutar, diam dengan pola tetap saat dijeda. */
@Composable
private fun Waveform(playing: Boolean, modifier: Modifier = Modifier) {
    if (playing) {
        val transition = rememberInfiniteTransition(label = "wave")
        val phase by transition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable<Float>(tween(1000, easing = LinearEasing)),
            label = "wavePhase",
        )
        WaveBars(modifier) { phase }
    } else {
        WaveBars(modifier) { -1f }
    }
}

private val WaveRest = floatArrayOf(0.40f, 0.70f, 1.00f, 0.70f, 0.40f)

@Composable
private fun WaveBars(modifier: Modifier, phase: () -> Float) {
    Canvas(modifier) {
        val p = phase()
        val bars = WaveRest.size
        val barW = size.width / (bars * 2 - 1)
        for (i in 0 until bars) {
            val level = if (p < 0f) {
                WaveRest[i]
            } else {
                0.3f + 0.7f * abs(sin((p + i * 0.17f) * 2f * PI.toFloat()))
            }
            val barH = size.height * level
            drawRoundRect(
                color = SambaColors.Accent,
                topLeft = Offset(i * 2 * barW, (size.height - barH) / 2f),
                size = Size(barW, barH),
                cornerRadius = CornerRadius(barW / 2f, barW / 2f),
            )
        }
    }
}

/** Ikon baterai: garis putih, isi oranye sesuai persen, kepala kecil di kanan. */
@Composable
private fun BatteryGlyph(level: Int, modifier: Modifier) {
    Canvas(modifier) {
        val stroke = 1.2.dp.toPx()
        val nub = 1.6.dp.toPx()
        val bodyW = size.width - nub
        drawRoundRect(
            color = SambaColors.TextPrimary,
            topLeft = Offset(stroke / 2f, stroke / 2f),
            size = Size(bodyW - stroke, size.height - stroke),
            cornerRadius = CornerRadius(2.5.dp.toPx()),
            style = Stroke(width = stroke),
        )
        val fraction = level.coerceIn(0, 100) / 100f
        val pad = stroke * 1.8f
        drawRoundRect(
            color = SambaColors.Accent,
            topLeft = Offset(pad, pad),
            size = Size((bodyW - pad * 2f) * fraction, size.height - pad * 2f),
            cornerRadius = CornerRadius(1.2.dp.toPx()),
        )
        drawRoundRect(
            color = SambaColors.TextPrimary,
            topLeft = Offset(bodyW, size.height * 0.3f),
            size = Size(nub, size.height * 0.4f),
            cornerRadius = CornerRadius(0.8.dp.toPx()),
        )
    }
}

private enum class Transport { Play, Pause, Next, Previous }

/** Tombol transport: ikon kecil tanpa latar, area sentuh 48dp. */
@Composable
private fun TransportButton(kind: Transport, label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(48.dp)
            .clip(CircleShape)
            .semantics { contentDescription = label }
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                role = Role.Button,
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        TransportIcon(kind, Modifier.size(16.dp))
    }
}

@Composable
private fun TransportIcon(kind: Transport, modifier: Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val color = SambaColors.TextPrimary
        when (kind) {
            Transport.Play -> {
                val path = Path().apply {
                    moveTo(w * 0.22f, h * 0.12f)
                    lineTo(w * 0.88f, h * 0.50f)
                    lineTo(w * 0.22f, h * 0.88f)
                    close()
                }
                drawPath(path, color)
            }
            Transport.Pause -> {
                drawRoundRect(color, Offset(w * 0.20f, h * 0.12f), Size(w * 0.22f, h * 0.76f), CornerRadius(w * 0.06f))
                drawRoundRect(color, Offset(w * 0.58f, h * 0.12f), Size(w * 0.22f, h * 0.76f), CornerRadius(w * 0.06f))
            }
            Transport.Next -> {
                val path = Path().apply {
                    moveTo(w * 0.12f, h * 0.15f)
                    lineTo(w * 0.70f, h * 0.50f)
                    lineTo(w * 0.12f, h * 0.85f)
                    close()
                }
                drawPath(path, color)
                drawRoundRect(color, Offset(w * 0.76f, h * 0.15f), Size(w * 0.12f, h * 0.70f), CornerRadius(w * 0.04f))
            }
            Transport.Previous -> {
                val path = Path().apply {
                    moveTo(w * 0.88f, h * 0.15f)
                    lineTo(w * 0.30f, h * 0.50f)
                    lineTo(w * 0.88f, h * 0.85f)
                    close()
                }
                drawPath(path, color)
                drawRoundRect(color, Offset(w * 0.12f, h * 0.15f), Size(w * 0.12f, h * 0.70f), CornerRadius(w * 0.04f))
            }
        }
    }
}

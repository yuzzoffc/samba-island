package app.samba.island

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.ui.platform.ComposeView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Foreground service yang memasang island sebagai overlay (TYPE_APPLICATION_OVERLAY),
 * memantau baterai, dan menjalankan MediaWatcher selama island aktif.
 * Service bukan Activity, jadi ia menjadi pemilik lifecycle/saved-state/viewmodel
 * untuk ComposeView secara manual.
 */
class IslandService : Service(), SavedStateRegistryOwner, ViewModelStoreOwner {

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val savedStateController = SavedStateRegistryController.create(this)
    private val store = ViewModelStore()

    override val lifecycle: Lifecycle
        get() = lifecycleRegistry
    override val savedStateRegistry: SavedStateRegistry
        get() = savedStateController.savedStateRegistry
    override val viewModelStore: ViewModelStore
        get() = store

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var windowManager: WindowManager
    private lateinit var media: MediaWatcher
    private var overlay: ComposeView? = null
    private var overlayParams: WindowManager.LayoutParams? = null
    private var receiverRegistered = false
    private var firstBattery = true

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent == null) return
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val percent = if (level >= 0 && scale > 0) level * 100 / scale else -1
            val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val charging = plugged && (
                status == BatteryManager.BATTERY_STATUS_CHARGING ||
                    status == BatteryManager.BATTERY_STATUS_FULL
                )
            val wasCharging = IslandBus.battery.value.charging
            IslandBus.battery.value = BatteryState(percent, charging)

            // Broadcast pertama hanya membaca kondisi awal, jangan memunculkan island.
            if (firstBattery) {
                firstBattery = false
                return
            }
            if (charging && !wasCharging && SambaStore.config.value.chargingEnabled) {
                IslandBus.show(ChargingEvent(IslandBus.nextId()))
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        savedStateController.performRestore(null)
        lifecycleRegistry.currentState = Lifecycle.State.RESUMED
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        media = MediaWatcher(this)
        SambaStore.load(this)
        IslandBus.event.value = null
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Wajib memanggil startForeground cepat setelah startForegroundService.
        if (!startAsForeground()) {
            stopSelf()
            return START_NOT_STICKY
        }
        val stopRequested = intent?.action == ACTION_STOP
        if (stopRequested || !Settings.canDrawOverlays(this)) {
            SambaStore.update(this) { it.copy(enabled = false) }
            stopSelf()
            return START_NOT_STICKY
        }
        if (overlay == null) showOverlay()
        // Dipanggil ulang tiap aplikasi dibuka, jadi akses notifikasi yang baru diberi ikut terbaca.
        if (overlay != null) media.ensureStarted()
        return START_STICKY
    }

    override fun onDestroy() {
        IslandBus.running = false
        if (receiverRegistered) {
            runCatching { unregisterReceiver(batteryReceiver) }
            receiverRegistered = false
        }
        if (::media.isInitialized) media.stop()
        overlay?.let { runCatching { windowManager.removeView(it) } }
        overlay = null
        overlayParams = null
        IslandBus.event.value = null
        lifecycleRegistry.currentState = Lifecycle.State.DESTROYED
        store.clear()
        scope.cancel()
        super.onDestroy()
    }

    private fun showOverlay() {
        val density = resources.displayMetrics.density
        val cfg = SambaStore.config.value

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        )
        params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        params.x = (cfg.offsetX * density).toInt()
        params.y = (cfg.offsetY * density).toInt()
        // Izinkan island digambar di area punch-hole / notch.
        if (Build.VERSION.SDK_INT >= 30) {
            params.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else if (Build.VERSION.SDK_INT >= 28) {
            params.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        val view = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@IslandService)
            setViewTreeSavedStateRegistryOwner(this@IslandService)
            setViewTreeViewModelStoreOwner(this@IslandService)
            setContent { IslandHost() }
        }

        try {
            windowManager.addView(view, params)
        } catch (e: Exception) {
            stopSelf()
            return
        }
        overlay = view
        overlayParams = params
        IslandBus.running = true

        // Pantau baterai untuk Charging Island.
        firstBattery = true
        ContextCompat.registerReceiver(
            this,
            batteryReceiver,
            IntentFilter(Intent.ACTION_BATTERY_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED,
        )
        receiverRegistered = true

        // Posisi mengikuti slider secara langsung.
        scope.launch {
            SambaStore.config.collect { c ->
                val lp = overlayParams ?: return@collect
                lp.x = (c.offsetX * density).toInt()
                lp.y = (c.offsetY * density).toInt()
                overlay?.let { runCatching { windowManager.updateViewLayout(it, lp) } }
            }
        }
    }

    private fun startAsForeground(): Boolean {
        return try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Island aktif", NotificationManager.IMPORTANCE_LOW)
            )
            val openApp = PendingIntent.getActivity(
                this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
            )
            val stop = PendingIntent.getService(
                this, 1,
                Intent(this, IslandService::class.java).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE
            )
            val notification = Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_stat_samba)
                .setContentTitle("SAMBA aktif")
                .setContentText("Island tampil di atas layar")
                .setContentIntent(openApp)
                .addAction(0, "Matikan", stop)
                .setOngoing(true)
                .build()
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(NOTIF_ID, notification)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    companion object {
        const val ACTION_STOP = "app.samba.island.STOP"
        private const val CHANNEL_ID = "samba_island"
        private const val NOTIF_ID = 1
    }
}

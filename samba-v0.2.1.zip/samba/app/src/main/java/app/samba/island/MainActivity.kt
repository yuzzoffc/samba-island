package app.samba.island

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.service.notification.NotificationListenerService
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {

    private var refresh by mutableIntStateOf(0)
    private var pendingEnable = false

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        SambaStore.load(this)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = SambaColors.Accent,
                    onPrimary = SambaColors.Ink,
                    secondary = SambaColors.Accent,
                    tertiary = SambaColors.Accent,
                    background = SambaColors.Ink,
                    surface = SambaColors.Ink,
                    onBackground = SambaColors.TextPrimary,
                    onSurface = SambaColors.TextPrimary,
                ),
            ) {
                SambaApp(
                    refresh = refresh,
                    onToggle = { on -> toggleIsland(on) },
                    onOverlaySettings = { openOverlaySettings() },
                    onAccessSettings = { openNotificationAccess() },
                    onAppSettings = { openAppSettings() },
                    onBatterySettings = { openBatterySettings() },
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refresh++
        val canDraw = Settings.canDrawOverlays(this)

        // Pengguna baru kembali dari layar izin setelah menekan toggle.
        if (pendingEnable) {
            pendingEnable = false
            if (canDraw) {
                toggleIsland(true)
                return
            }
        }
        // Jaga island tetap sinkron dengan toggle.
        if (SambaStore.config.value.enabled) {
            if (canDraw) {
                ContextCompat.startForegroundService(this, Intent(this, IslandService::class.java))
            } else {
                SambaStore.update(this) { it.copy(enabled = false) }
            }
        }
        // Jika akses notifikasi sudah ada tapi listener belum tersambung, minta sistem menyambungkan ulang.
        val hasAccess = NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
        if (hasAccess && !IslandBus.listenerConnected) {
            try {
                NotificationListenerService.requestRebind(
                    ComponentName(this, SambaNotificationListener::class.java)
                )
            } catch (e: Exception) {
                // Beberapa perangkat menolak. Tidak fatal.
            }
        }
    }

    private fun toggleIsland(on: Boolean) {
        val service = Intent(this, IslandService::class.java)
        if (!on) {
            SambaStore.update(this) { it.copy(enabled = false) }
            stopService(service)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            pendingEnable = true
            openOverlaySettings()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        SambaStore.update(this) { it.copy(enabled = true) }
        ContextCompat.startForegroundService(this, service)
    }

    private fun openOverlaySettings() {
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    private fun openNotificationAccess() {
        try {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        } catch (e: Exception) {
            openAppSettings()
        }
    }

    private fun openBatterySettings() {
        try {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        } catch (e: Exception) {
            openAppSettings()
        }
    }

    private fun openAppSettings() {
        startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
        )
    }
}

private enum class Page(val label: String) {
    HOME("Home"),
    CUSTOMIZE("Customize"),
    NOTIFICATIONS("Notifications"),
    SETTINGS("Settings"),
}

private class AppEntry(val pkg: String, val label: String)

private sealed interface AppListState {
    data object Loading : AppListState
    data object Failed : AppListState
    data class Ready(val apps: List<AppEntry>) : AppListState
}

/** Hasil terakhir daftar aplikasi, supaya halaman Notifications tidak kosong saat dibuka lagi. */
private var cachedApps: List<AppEntry>? = null

// Data contoh untuk pratinjau. Sengaja diberi tulisan "Contoh" supaya tidak terbaca sebagai data asli.
private val DemoMedia = MediaInfo(
    title = "Contoh judul lagu",
    artist = "Contoh artis",
    art = null,
    playing = true,
    duration = 215_000L,
)

private val DemoNotification = NotificationEvent(
    id = -1L,
    appName = "Contoh",
    title = "Contoh pengirim",
    text = "Contoh isi pesan yang tampil di island.",
    icon = null,
    intent = null,
)

private val PreviewLabels = listOf("Compact", "Music", "Notification", "Charging")

private fun loadLaunchableApps(context: Context, allowed: Set<String>): List<AppEntry> {
    val pm = context.packageManager
    val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(launcher, 0)
        .map { AppEntry(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
        .filter { it.pkg != context.packageName }
        .distinctBy { it.pkg }
        .sortedWith(
            compareByDescending<AppEntry> { it.pkg in allowed }.thenBy { it.label.lowercase() }
        )
}

@Composable
private fun SambaApp(
    refresh: Int,
    onToggle: (Boolean) -> Unit,
    onOverlaySettings: () -> Unit,
    onAccessSettings: () -> Unit,
    onAppSettings: () -> Unit,
    onBatterySettings: () -> Unit,
) {
    val context = LocalContext.current
    val cfg by SambaStore.config.collectAsState()
    val canOverlay = remember(refresh) { Settings.canDrawOverlays(context) }
    val hasAccess = remember(refresh) {
        NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)
    }
    var page by rememberSaveable { mutableStateOf(Page.HOME) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SambaColors.Ink)
            .statusBarsPadding(),
    ) {
        Box(Modifier.weight(1f)) {
            Crossfade(targetState = page, animationSpec = tween(140), label = "page") { p ->
                when (p) {
                    Page.HOME -> HomeScreen(cfg, canOverlay, onToggle, onOverlaySettings)
                    Page.CUSTOMIZE -> CustomizeScreen(cfg)
                    Page.NOTIFICATIONS ->
                        NotificationsScreen(cfg, hasAccess, refresh, onAccessSettings, onAppSettings)
                    Page.SETTINGS -> SettingsScreen(
                        canOverlay, hasAccess, onOverlaySettings, onAccessSettings, onAppSettings, onBatterySettings
                    )
                }
            }
        }
        HorizontalDivider(color = SambaColors.Line)
        BottomBar(page) { page = it }
    }
}

@Composable
private fun BottomBar(selected: Page, onSelect: (Page) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(SambaColors.Ink)
            .navigationBarsPadding(),
    ) {
        for (p in Page.values()) {
            val isSelected = p == selected
            Column(
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 56.dp)
                    .selectable(selected = isSelected, role = Role.Tab, onClick = { onSelect(p) })
                    .padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Box(
                    Modifier
                        .width(22.dp)
                        .height(3.dp)
                        .clip(CircleShape)
                        .background(if (isSelected) SambaColors.Accent else Color.Transparent)
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    p.label,
                    color = if (isSelected) SambaColors.TextPrimary else SambaColors.Muted,
                    fontSize = 11.sp,
                    fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
private fun HomeScreen(
    cfg: IslandConfig,
    canOverlay: Boolean,
    onToggle: (Boolean) -> Unit,
    onOverlaySettings: () -> Unit,
) {
    var kind by remember { mutableIntStateOf(0) }
    var open by remember { mutableStateOf(false) }
    val mode: IslandMode = when (kind) {
        1 -> if (open) IslandMode.MusicOpen(DemoMedia) else IslandMode.MusicMini(DemoMedia)
        2 -> IslandMode.Notification(DemoNotification)
        3 -> IslandMode.Charging
        else -> if (open) IslandMode.Peek else IslandMode.Compact
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text(
                    "SAMBA",
                    color = SambaColors.TextPrimary,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 4.sp,
                )
                Text("Dynamic Island for Android", color = SambaColors.Muted, fontSize = 13.sp)
            }
        }

        // Fokus layar ini: island itu sendiri. Pilihan jenis island ada tepat di bawahnya.
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            PreviewPanel(height = 206.dp, caption = "Pratinjau dengan data contoh") {
                IslandView(
                    mode = mode,
                    cfg = cfg,
                    fixedProgress = 0.4f,
                    onTap = {
                        if (kind == 0 || kind == 1) open = !open
                    },
                )
            }
            KindSelector(selected = kind) { i ->
                kind = i
                open = false
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 56.dp)
                .toggleable(value = cfg.enabled, role = Role.Switch, onValueChange = onToggle),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    "Island",
                    color = SambaColors.TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                )
                Text(
                    if (cfg.enabled) "Aktif di atas layar" else "Nonaktif",
                    color = SambaColors.Muted,
                    fontSize = 13.sp,
                )
            }
            Switch(checked = cfg.enabled, onCheckedChange = null, colors = sambaSwitchColors())
        }

        if (!canOverlay) {
            Notice(
                title = "Izin belum aktif",
                body = "Tanpa izin 'Tampil di atas aplikasi lain', island tidak bisa muncul di layar.",
                action = "Aktifkan izin",
                onAction = onOverlaySettings,
            )
        }
    }
}

@Composable
private fun CustomizeScreen(cfg: IslandConfig) {
    val context = LocalContext.current
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 20.dp),
    ) {
        ScreenTitle(
            "Posisi dan ukuran",
            if (cfg.enabled) {
                "Perubahan langsung terlihat di layar."
            } else {
                "Nyalakan Island di Home agar perubahan terlihat langsung di layar."
            },
        )
        Spacer(Modifier.height(16.dp))
        PreviewPanel(height = 104.dp, caption = "Ukuran sebenarnya") {
            IslandView(mode = IslandMode.Compact, cfg = cfg)
        }
        Spacer(Modifier.height(8.dp))

        SliderRow("Posisi vertikal", cfg.offsetY, 0..80, "dp") { v ->
            SambaStore.update(context) { it.copy(offsetY = v) }
        }
        SliderRow("Posisi horizontal", cfg.offsetX, -150..150, "dp") { v ->
            SambaStore.update(context) { it.copy(offsetX = v) }
        }
        SliderRow("Lebar", cfg.width, 80..220, "dp") { v ->
            SambaStore.update(context) { it.copy(width = v) }
        }
        SliderRow("Tinggi", cfg.height, 24..52, "dp") { v ->
            SambaStore.update(context) { it.copy(height = v) }
        }
        TextAction("Kembalikan ke bawaan") {
            val d = IslandConfig()
            SambaStore.update(context) { cur ->
                cur.copy(offsetX = d.offsetX, offsetY = d.offsetY, width = d.width, height = d.height)
            }
        }

        Spacer(Modifier.height(20.dp))
        HorizontalDivider(color = SambaColors.Line)
        Spacer(Modifier.height(20.dp))

        SectionTitle("Tampil di island")
        Spacer(Modifier.height(4.dp))
        SwitchRow("Notifikasi", "Pesan dari aplikasi yang kamu pilih.", cfg.notifEnabled) { on ->
            SambaStore.update(context) { it.copy(notifEnabled = on) }
        }
        SwitchRow("Musik", "Judul lagu, kontrol putar, dan animasi audio.", cfg.musicEnabled) { on ->
            SambaStore.update(context) { it.copy(musicEnabled = on) }
        }
        SwitchRow("Pengisian daya", "Persentase baterai saat charger dicolok.", cfg.chargingEnabled) { on ->
            SambaStore.update(context) { it.copy(chargingEnabled = on) }
        }
    }
}

@Composable
private fun NotificationsScreen(
    cfg: IslandConfig,
    hasAccess: Boolean,
    refresh: Int,
    onAccessSettings: () -> Unit,
    onAppSettings: () -> Unit,
) {
    val context = LocalContext.current
    var attempt by remember { mutableIntStateOf(0) }
    val initial: AppListState = cachedApps?.let { AppListState.Ready(it) } ?: AppListState.Loading
    val listState by produceState<AppListState>(initial, refresh, attempt) {
        value = withContext(Dispatchers.Default) {
            try {
                val list = loadLaunchableApps(context, SambaStore.config.value.allowedApps)
                cachedApps = list
                AppListState.Ready(list)
            } catch (e: Exception) {
                AppListState.Failed
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 20.dp),
    ) {
        item {
            Column(Modifier.padding(bottom = 20.dp)) {
                ScreenTitle(
                    "Notifications",
                    "Pilih aplikasi yang boleh muncul di island. Isi notifikasi hanya diproses di ponselmu dan tidak disimpan.",
                )
            }
        }

        if (!hasAccess) {
            item {
                Column(Modifier.padding(bottom = 20.dp)) {
                    Notice(
                        title = "Akses notifikasi belum aktif",
                        body = "Island butuh akses notifikasi untuk menampilkan pesan dan membaca musik yang sedang diputar.",
                        action = "Beri akses notifikasi",
                        onAction = onAccessSettings,
                    )
                    if (Build.VERSION.SDK_INT >= 33) {
                        Spacer(Modifier.height(10.dp))
                        Text(
                            "Jika tombol akses berwarna abu-abu: buka Info aplikasi, ketuk menu titik tiga di pojok kanan atas, lalu pilih Izinkan setelan terbatas.",
                            color = SambaColors.Muted,
                            fontSize = 12.sp,
                            lineHeight = 17.sp,
                        )
                        TextAction("Buka info aplikasi", onAppSettings)
                    }
                }
            }
        }

        item {
            Column {
                SwitchRow("Tampilkan notifikasi di island", null, cfg.notifEnabled) { on ->
                    SambaStore.update(context) { it.copy(notifEnabled = on) }
                }
                SwitchRow(
                    "Sembunyikan isi pesan saat layar terkunci",
                    "Island hanya menampilkan nama aplikasi dan tulisan Pesan baru.",
                    cfg.hideOnLock,
                ) { on ->
                    SambaStore.update(context) { it.copy(hideOnLock = on) }
                }
                SliderRow("Lama tampil", cfg.notifSeconds, 2..10, "detik") { v ->
                    SambaStore.update(context) { it.copy(notifSeconds = v) }
                }
                Spacer(Modifier.height(12.dp))
                PrimaryButton(
                    text = "Kirim notifikasi uji",
                    enabled = cfg.enabled,
                    onClick = {
                        IslandBus.show(
                            NotificationEvent(
                                id = IslandBus.nextId(),
                                appName = "SAMBA",
                                title = "Notifikasi uji",
                                text = "Island menerima notifikasi seperti ini.",
                                icon = null,
                                intent = null,
                            )
                        )
                    },
                )
                if (!cfg.enabled) {
                    Spacer(Modifier.height(6.dp))
                    Text("Nyalakan Island di Home dulu.", color = SambaColors.Muted, fontSize = 12.sp)
                }
                Spacer(Modifier.height(20.dp))
                HorizontalDivider(color = SambaColors.Line)
                Spacer(Modifier.height(20.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f)) { SectionTitle("Aplikasi yang boleh tampil") }
                    val selectedCount =
                        (listState as? AppListState.Ready)?.apps?.count { it.pkg in cfg.allowedApps }
                    if (selectedCount != null) {
                        Text("$selectedCount dipilih", color = SambaColors.Muted, fontSize = 13.sp)
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }

        when (val s = listState) {
            AppListState.Loading -> item { LoadingRow() }
            AppListState.Failed -> item { ErrorRow(onRetry = { attempt++ }) }
            is AppListState.Ready -> {
                if (s.apps.isEmpty()) {
                    item { EmptyRow() }
                } else {
                    items(s.apps, key = { it.pkg }) { app ->
                        AppRow(
                            app = app,
                            checked = app.pkg in cfg.allowedApps,
                            onChange = { on ->
                                SambaStore.update(context) { c ->
                                    c.copy(
                                        allowedApps = if (on) c.allowedApps + app.pkg else c.allowedApps - app.pkg
                                    )
                                }
                            },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(
    canOverlay: Boolean,
    hasAccess: Boolean,
    onOverlaySettings: () -> Unit,
    onAccessSettings: () -> Unit,
    onAppSettings: () -> Unit,
    onBatterySettings: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 20.dp),
    ) {
        ScreenTitle("Izin")
        Spacer(Modifier.height(8.dp))
        StatusRow("Tampil di atas aplikasi lain", canOverlay, "Buka", onOverlaySettings)
        StatusRow("Akses notifikasi", hasAccess, "Buka", onAccessSettings)
        TextAction("Pengaturan baterai (agar island tidak dimatikan sistem)", onBatterySettings)
        TextAction("Info aplikasi", onAppSettings)

        Spacer(Modifier.height(20.dp))
        HorizontalDivider(color = SambaColors.Line)
        Spacer(Modifier.height(20.dp))

        ScreenTitle("Privasi")
        Spacer(Modifier.height(8.dp))
        Text(
            "SAMBA tidak meminta izin internet (bisa dicek di Info aplikasi), jadi tidak mengirim data lewat jaringan.\n\n" +
                "Isi notifikasi hanya diproses di memori selama island tampil dan tidak disimpan.\n\n" +
                "Hanya aplikasi yang kamu pilih di halaman Notifications yang bisa muncul. Isi pesan bisa disembunyikan saat layar terkunci.\n\n" +
                "Untuk mencabut akses, ketuk Buka di baris izin di atas lalu matikan SAMBA.",
            color = SambaColors.Muted,
            fontSize = 13.sp,
            lineHeight = 20.sp,
        )

        Spacer(Modifier.height(20.dp))
        HorizontalDivider(color = SambaColors.Line)
        Spacer(Modifier.height(20.dp))

        ScreenTitle("Cara mengaktifkan")
        Spacer(Modifier.height(8.dp))
        Text(
            "1. Di Home, nyalakan toggle Island dan izinkan 'Tampil di atas aplikasi lain'.\n" +
                "2. Di Notifications, beri akses notifikasi lalu pilih aplikasinya.\n" +
                "3. Di Customize, geser posisi sampai island pas dengan punch-hole kamera.",
            color = SambaColors.Muted,
            fontSize = 13.sp,
            lineHeight = 20.sp,
        )

        Spacer(Modifier.height(28.dp))
        Text("Versi 0.2.1 (Fase 2)", color = SambaColors.Muted, fontSize = 12.sp)
    }
}

@Composable
private fun PreviewPanel(height: androidx.compose.ui.unit.Dp, caption: String?, content: @Composable () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(height)
            .clip(RoundedCornerShape(24.dp))
            .background(SambaColors.Cream),
        contentAlignment = Alignment.TopCenter,
    ) {
        Box(Modifier.padding(top = 14.dp)) { content() }
        if (caption != null) {
            Text(
                caption,
                color = SambaColors.CreamText,
                fontSize = 12.sp,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 12.dp),
            )
        }
    }
}

@Composable
private fun KindSelector(selected: Int, onSelect: (Int) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(SambaColors.Surface)
            .padding(4.dp),
    ) {
        PreviewLabels.forEachIndexed { i, label ->
            val isSelected = i == selected
            Box(
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 44.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isSelected) SambaColors.Tile else Color.Transparent)
                    .selectable(selected = isSelected, role = Role.Tab, onClick = { onSelect(i) }),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    label,
                    color = if (isSelected) SambaColors.TextPrimary else SambaColors.Muted,
                    fontSize = 12.sp,
                    fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
private fun ScreenTitle(title: String, subtitle: String? = null) {
    Column {
        Text(title, color = SambaColors.TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        if (subtitle != null) {
            Spacer(Modifier.height(4.dp))
            Text(subtitle, color = SambaColors.Muted, fontSize = 13.sp, lineHeight = 19.sp)
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, color = SambaColors.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
}

@Composable
private fun Notice(title: String, body: String, action: String, onAction: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(SambaColors.Surface)
            .padding(16.dp),
    ) {
        Text(title, color = SambaColors.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Text(body, color = SambaColors.Muted, fontSize = 13.sp, lineHeight = 19.sp)
        Spacer(Modifier.height(12.dp))
        PrimaryButton(text = action, onClick = onAction)
    }
}

@Composable
private fun PrimaryButton(text: String, onClick: () -> Unit, enabled: Boolean = true) {
    Button(
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(10.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = SambaColors.Accent,
            contentColor = SambaColors.Ink,
            disabledContainerColor = SambaColors.Line,
            disabledContentColor = SambaColors.Muted,
        ),
    ) {
        Text(text, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun TextAction(text: String, onClick: () -> Unit) {
    TextButton(onClick = onClick, shape = RoundedCornerShape(10.dp)) {
        Text(
            text,
            color = SambaColors.TextPrimary,
            fontSize = 14.sp,
            textDecoration = TextDecoration.Underline,
        )
    }
}

@Composable
private fun sambaSwitchColors(): SwitchColors =
    SwitchDefaults.colors(
        checkedThumbColor = SambaColors.Ink,
        checkedTrackColor = SambaColors.Accent,
        checkedBorderColor = SambaColors.Accent,
        uncheckedThumbColor = SambaColors.Muted,
        uncheckedTrackColor = SambaColors.Ink,
        uncheckedBorderColor = SambaColors.Muted,
    )

@Composable
private fun SwitchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .toggleable(value = checked, role = Role.Switch, onValueChange = onChange)
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = SambaColors.TextPrimary, fontSize = 15.sp)
            if (subtitle != null) {
                Text(subtitle, color = SambaColors.Muted, fontSize = 12.sp, lineHeight = 17.sp)
            }
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = null, colors = sambaSwitchColors())
    }
}

@Composable
private fun SliderRow(label: String, value: Int, range: IntRange, unit: String, onChange: (Int) -> Unit) {
    Column(Modifier.padding(top = 8.dp)) {
        Row {
            Text(label, color = SambaColors.TextPrimary, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Text("$value $unit", color = SambaColors.Muted, fontSize = 13.sp)
        }
        Slider(
            value = value.toFloat(),
            onValueChange = { onChange(it.toInt()) },
            valueRange = range.first.toFloat()..range.last.toFloat(),
            modifier = Modifier.semantics { contentDescription = "$label, $value $unit" },
            colors = SliderDefaults.colors(
                thumbColor = SambaColors.TextPrimary,
                activeTrackColor = SambaColors.TextPrimary,
                inactiveTrackColor = SambaColors.Line,
            ),
        )
    }
}

@Composable
private fun StatusRow(title: String, ok: Boolean, action: String, onAction: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = SambaColors.TextPrimary, fontSize = 15.sp)
            Text(
                if (ok) "Aktif" else "Belum aktif",
                color = if (ok) SambaColors.Accent else SambaColors.TextPrimary,
                fontSize = 12.sp,
            )
        }
        TextAction(action, onAction)
    }
}

@Composable
private fun LoadingRow() {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CircularProgressIndicator(
            modifier = Modifier.size(20.dp),
            color = SambaColors.Muted,
            strokeWidth = 2.dp,
        )
        Spacer(Modifier.width(12.dp))
        Text("Memuat daftar aplikasi", color = SambaColors.Muted, fontSize = 14.sp)
    }
}

@Composable
private fun EmptyRow() {
    Column(Modifier.fillMaxWidth().padding(vertical = 16.dp)) {
        Text("Tidak ada aplikasi yang bisa dipilih", color = SambaColors.TextPrimary, fontSize = 15.sp)
        Spacer(Modifier.height(4.dp))
        Text(
            "Hanya aplikasi dengan ikon di layar utama yang muncul di sini.",
            color = SambaColors.Muted,
            fontSize = 13.sp,
        )
    }
}

@Composable
private fun ErrorRow(onRetry: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 16.dp)) {
        Text("Daftar aplikasi gagal dimuat", color = SambaColors.TextPrimary, fontSize = 15.sp)
        TextAction("Coba lagi", onRetry)
    }
}

@Composable
private fun AppRow(app: AppEntry, checked: Boolean, onChange: (Boolean) -> Unit) {
    val context = LocalContext.current
    val icon by produceState<ImageBitmap?>(null, app.pkg) {
        value = withContext(Dispatchers.IO) { AppIcons.get(context, app.pkg) }
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .toggleable(value = checked, role = Role.Switch, onValueChange = onChange)
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        val img = icon
        if (img != null) {
            Image(
                bitmap = img,
                contentDescription = null,
                modifier = Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)),
            )
        } else {
            Box(
                Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(SambaColors.Surface)
            )
        }
        Spacer(Modifier.width(12.dp))
        Text(
            app.label,
            color = SambaColors.TextPrimary,
            fontSize = 15.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
        Switch(checked = checked, onCheckedChange = null, colors = sambaSwitchColors())
    }
}

package app.samba.island

import android.content.Context
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import java.util.concurrent.ConcurrentHashMap

/** Cache kecil untuk ikon aplikasi (dipakai island dan daftar aplikasi). */
object AppIcons {
    private val cache = ConcurrentHashMap<String, ImageBitmap>()

    fun get(context: Context, pkg: String): ImageBitmap? {
        cache[pkg]?.let { return it }
        val image = try {
            context.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap()
        } catch (e: Exception) {
            null
        }
        if (image != null) cache[pkg] = image
        return image
    }
}

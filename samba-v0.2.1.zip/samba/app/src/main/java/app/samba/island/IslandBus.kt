package app.samba.island

import android.app.ActivityOptions
import android.app.PendingIntent
import android.content.Context
import android.graphics.Bitmap
import android.media.session.MediaController
import android.media.session.PlaybackState
import android.os.Build
import androidx.compose.ui.graphics.ImageBitmap
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.concurrent.atomic.AtomicLong

/** Kejadian sementara yang tampil di island lalu hilang sendiri. */
sealed interface IslandEvent {
    val id: Long
}

class NotificationEvent(
    override val id: Long,
    val appName: String,
    val title: String,
    val text: String,
    val icon: ImageBitmap?,
    val intent: PendingIntent?,
) : IslandEvent

class ChargingEvent(override val id: Long) : IslandEvent

data class MediaInfo(
    val title: String,
    val artist: String,
    val art: Bitmap?,
    val playing: Boolean,
    val duration: Long,
)

data class MediaProgress(
    val position: Long = 0L,
    val updateTime: Long = 0L,
    val speed: Float = 1f,
)

data class BatteryState(val level: Int = -1, val charging: Boolean = false)

/** Tampilan island saat ini. */
sealed interface IslandMode {
    data object Compact : IslandMode
    data object Peek : IslandMode
    data object Charging : IslandMode
    data class MusicMini(val media: MediaInfo) : IslandMode
    data class MusicOpen(val media: MediaInfo) : IslandMode
    data class Notification(val event: NotificationEvent) : IslandMode
}

/** Penghubung antara sumber data (listener, media, baterai) dan tampilan island. */
object IslandBus {
    val event = MutableStateFlow<IslandEvent?>(null)
    val media = MutableStateFlow<MediaInfo?>(null)
    val progress = MutableStateFlow(MediaProgress())
    val battery = MutableStateFlow(BatteryState())

    @Volatile
    var running = false

    @Volatile
    var listenerConnected = false

    @Volatile
    var controller: MediaController? = null

    private val ids = AtomicLong(0)

    fun nextId(): Long = ids.incrementAndGet()

    fun show(e: IslandEvent) {
        event.value = e
    }

    fun clear(id: Long) {
        if (event.value?.id == id) event.value = null
    }

    fun playPause() {
        val c = controller ?: return
        if (c.playbackState?.state == PlaybackState.STATE_PLAYING) {
            c.transportControls.pause()
        } else {
            c.transportControls.play()
        }
    }

    fun next() {
        controller?.transportControls?.skipToNext()
    }

    fun previous() {
        controller?.transportControls?.skipToPrevious()
    }

    /** Membuka aplikasi asal notifikasi lewat PendingIntent miliknya. */
    fun open(context: Context, e: NotificationEvent) {
        val pi = e.intent ?: return
        try {
            val options = if (Build.VERSION.SDK_INT >= 34) {
                ActivityOptions.makeBasic()
                    .setPendingIntentBackgroundActivityStartMode(
                        ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED
                    )
                    .toBundle()
            } else {
                null
            }
            pi.send(context, 0, null, null, null, null, options)
        } catch (ex: Exception) {
            // Intent sudah tidak berlaku atau diblokir sistem. Abaikan.
        }
    }
}

package app.samba.island

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.core.app.NotificationManagerCompat

/**
 * Memantau sesi media aktif (Spotify, YouTube Music, dll.) dan menerbitkannya ke IslandBus.
 * MediaSessionManager hanya mengizinkan ini bila akses notifikasi aplikasi sudah aktif.
 */
class MediaWatcher(private val context: Context) {

    private val manager = context.getSystemService(MediaSessionManager::class.java)
    private val component = ComponentName(context, SambaNotificationListener::class.java)
    private val handler = Handler(Looper.getMainLooper())

    private var controller: MediaController? = null
    private var started = false
    private var lastArtSource: Bitmap? = null
    private var lastArtScaled: Bitmap? = null

    private val hideLater = Runnable { IslandBus.media.value = null }

    private val callback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) {
            publish()
        }

        override fun onMetadataChanged(metadata: MediaMetadata?) {
            publish()
        }

        override fun onSessionDestroyed() {
            pick(sessions())
        }
    }

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> pick(list.orEmpty()) }

    fun ensureStarted() {
        val hasAccess = NotificationManagerCompat.getEnabledListenerPackages(context)
            .contains(context.packageName)
        if (!hasAccess) {
            stop()
            return
        }
        if (started) return
        try {
            manager.addOnActiveSessionsChangedListener(sessionsListener, component)
            started = true
            pick(sessions())
        } catch (e: SecurityException) {
            started = false
        }
    }

    fun stop() {
        if (started) {
            try {
                manager.removeOnActiveSessionsChangedListener(sessionsListener)
            } catch (e: Exception) {
                // Sudah dilepas oleh sistem.
            }
        }
        started = false
        select(null)
    }

    private fun sessions(): List<MediaController> =
        try {
            manager.getActiveSessions(component)
        } catch (e: SecurityException) {
            emptyList()
        }

    private fun pick(list: List<MediaController>) {
        val best = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list.firstOrNull()
        select(best)
    }

    private fun select(next: MediaController?) {
        val same = next?.sessionToken == controller?.sessionToken
        if (!same) {
            controller?.unregisterCallback(callback)
            controller = next
            IslandBus.controller = next
            next?.registerCallback(callback, handler)
        }
        publish()
    }

    private fun publish() {
        handler.removeCallbacks(hideLater)
        val c = controller
        val st = c?.playbackState
        val md = c?.metadata
        if (c == null || st == null || md == null) {
            IslandBus.media.value = null
            return
        }

        val playing = st.state == PlaybackState.STATE_PLAYING ||
            st.state == PlaybackState.STATE_BUFFERING
        val paused = st.state == PlaybackState.STATE_PAUSED
        val title = md.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
            ?: ""
        if ((!playing && !paused) || title.isBlank()) {
            IslandBus.media.value = null
            return
        }

        val artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)
            ?: ""
        val source = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)

        IslandBus.progress.value = MediaProgress(
            position = st.position,
            updateTime = if (st.lastPositionUpdateTime > 0L) {
                st.lastPositionUpdateTime
            } else {
                SystemClock.elapsedRealtime()
            },
            speed = if (st.playbackSpeed > 0f) st.playbackSpeed else 1f,
        )
        IslandBus.media.value = MediaInfo(
            title = title,
            artist = artist,
            art = scaledArt(source),
            playing = playing,
            duration = md.getLong(MediaMetadata.METADATA_KEY_DURATION),
        )

        // Jika dijeda lama, sembunyikan island musik.
        if (!playing) handler.postDelayed(hideLater, 30_000L)
    }

    private fun scaledArt(src: Bitmap?): Bitmap? {
        if (src == null) return null
        if (src === lastArtSource) return lastArtScaled
        val longest = maxOf(src.width, src.height)
        val out = if (longest <= 192) {
            src
        } else {
            val scale = 192f / longest
            try {
                Bitmap.createScaledBitmap(
                    src,
                    (src.width * scale).toInt().coerceAtLeast(1),
                    (src.height * scale).toInt().coerceAtLeast(1),
                    true,
                )
            } catch (e: Exception) {
                src
            }
        }
        lastArtSource = src
        lastArtScaled = out
        return out
    }
}

package app.samba.island

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Aplikasi yang boleh tampil di Notification Island secara bawaan. */
val DefaultAllowedApps: Set<String> = setOf(
    "com.whatsapp",
    "com.whatsapp.w4b",
    "org.telegram.messenger",
    "org.telegram.messenger.web",
    "org.thunderdog.challegram",
    "com.instagram.android",
)

/** Ukuran dalam dp. offsetX dihitung dari tengah layar, offsetY dari tepi atas. */
data class IslandConfig(
    val enabled: Boolean = false,
    val offsetX: Int = 0,
    val offsetY: Int = 8,
    val width: Int = 120,
    val height: Int = 34,
    val notifEnabled: Boolean = true,
    val hideOnLock: Boolean = true,
    val notifSeconds: Int = 5,
    val musicEnabled: Boolean = true,
    val chargingEnabled: Boolean = true,
    val allowedApps: Set<String> = DefaultAllowedApps,
)

/** Satu sumber kebenaran untuk Activity, Service, dan Listener (satu proses). */
object SambaStore {
    private const val FILE = "samba_prefs"
    private var loaded = false
    private val _config = MutableStateFlow(IslandConfig())
    val config: StateFlow<IslandConfig> = _config.asStateFlow()

    fun load(context: Context) {
        if (loaded) return
        loaded = true
        val p = context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val d = IslandConfig()
        _config.value = IslandConfig(
            enabled = p.getBoolean("enabled", d.enabled),
            offsetX = p.getInt("offsetX", d.offsetX),
            offsetY = p.getInt("offsetY", d.offsetY),
            width = p.getInt("width", d.width),
            height = p.getInt("height", d.height),
            notifEnabled = p.getBoolean("notifEnabled", d.notifEnabled),
            hideOnLock = p.getBoolean("hideOnLock", d.hideOnLock),
            notifSeconds = p.getInt("notifSeconds", d.notifSeconds),
            musicEnabled = p.getBoolean("musicEnabled", d.musicEnabled),
            chargingEnabled = p.getBoolean("chargingEnabled", d.chargingEnabled),
            allowedApps = p.getStringSet("allowedApps", null)?.toSet() ?: d.allowedApps,
        )
    }

    fun update(context: Context, change: (IslandConfig) -> IslandConfig) {
        val next = change(_config.value)
        _config.value = next
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putBoolean("enabled", next.enabled)
            .putInt("offsetX", next.offsetX)
            .putInt("offsetY", next.offsetY)
            .putInt("width", next.width)
            .putInt("height", next.height)
            .putBoolean("notifEnabled", next.notifEnabled)
            .putBoolean("hideOnLock", next.hideOnLock)
            .putInt("notifSeconds", next.notifSeconds)
            .putBoolean("musicEnabled", next.musicEnabled)
            .putBoolean("chargingEnabled", next.chargingEnabled)
            .putStringSet("allowedApps", next.allowedApps.toSet())
            .apply()
    }
}

# DESIGN.md: SAMBA

Arah desain dari pemilik produk. Isinya dipindahkan dari dokumen konsep SAMBA dan gambar contoh
"Island: enam kondisi", bukan dikarang. Warna di bawah diambil langsung dari piksel gambar contoh.

## Identitas
- Nama: SAMBA (Smart Android Mini Bar Assistant)
- Tagline: "Your Screen. Your Island." dan "Notifikasi kecil, pengalaman lebih cerdas."
- Kepribadian: premium, minimalis, tenang, animasi lembut

## Arah visual (gambar contoh, menggantikan palet neon di dokumen konsep)
- Island: hitam murni #000000, tanpa garis tepi, tanpa gradasi
- Satu aksen: oranye #F0561F (gelombang audio, isi baterai, progres)
- Netral hangat: tile #3A372F, trek progres #2E2B24, teks sekunder pada hitam #B5AFA1, teks utama putih
- Papan pratinjau: krem #F2EEE6, teks gelap #17150F, teks redup #5E584C
- Latar aplikasi: #08090D (dari dokumen konsep)

## Enam kondisi island
- Compact: kosong, menutupi punch-hole
- Peek: tulisan SAMBA di tengah
- Charging: ikon baterai di kiri, persen di kanan
- MusicMini: cover di kiri, gelombang audio di kanan
- MusicOpen: cover, judul, artis, gelombang, progres, sebelumnya/putar/berikutnya
- Notification: tile aplikasi, nama aplikasi, pengirim, isi pesan

Ukuran acuan (dp, dari rasio gambar contoh): compact 120x34, peek 170x34, charging 190x34,
musicmini 208x34, notification 320x68, musicopen 320x148.

## Tipografi
Sans bawaan sistem. Judul tebal, teks sekunder biasa. Wordmark SAMBA memakai spasi huruf lebar.

## Catatan terbuka
Ikon peluncur dan logo masih versi dokumen konsep (titik biru, batang ungu). Belum diubah
sebelum pemilik produk menyetujui.

Dial: ENERGY 2 / RHYTHM 2 / MOTION 2

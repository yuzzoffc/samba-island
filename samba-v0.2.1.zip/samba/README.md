# SAMBA: Dynamic Island for Android

Fase 2 (Smart Island), versi 0.2.1. Desain mengikuti gambar contoh "Island: enam kondisi" (lihat DESIGN.md).
Kotlin + Jetpack Compose, minSdk 26, targetSdk 35.

## Enam kondisi island
- Compact: pil hitam kosong yang menutupi punch-hole. Ketuk untuk Peek.
- Peek: tulisan SAMBA sebentar.
- Charging: ikon baterai dan persen saat charger dicolok.
- MusicMini: cover dan gelombang audio saat musik diputar. Ketuk untuk MusicOpen.
- MusicOpen: judul, artis, progres, sebelumnya, putar/jeda, berikutnya.
- Notification: tile aplikasi, nama aplikasi, pengirim, isi pesan. Ketuk untuk membuka aplikasinya.

## Halaman aplikasi
Home (pratinjau dan toggle), Customize (posisi, ukuran, kondisi yang tampil), Notifications (akses dan pilihan aplikasi), Settings (izin, privasi, panduan).

## Privasi
- Tidak meminta izin INTERNET (bisa dicek di Info aplikasi), jadi tidak mengirim data lewat jaringan.
- Akses notifikasi diberikan sendiri oleh pengguna dan bisa dicabut kapan saja.
- Hanya aplikasi yang dipilih yang diteruskan ke island. Isi notifikasi tidak disimpan.
- Isi pesan bisa disembunyikan saat layar terkunci.

## Cara mendapatkan APK
### Dari HP, tanpa PC (GitHub Actions)
1. Buat repositori GitHub baru. Kalau sudah punya, hapus zip lama di repositori lebih dulu.
2. Add file, Upload files: unggah `samba-v0.2.1.zip` dan `build-apk.yml` tanpa diekstrak.
3. Buka `build-apk.yml`, ketuk ikon pensil, ubah nama file menjadi `.github/workflows/build-apk.yml`, lalu Commit.
4. Tab Actions: tunggu build selesai (sekitar 6 sampai 10 menit pertama).
5. Buka Releases, unduh `SAMBA.apk`, lalu pasang.

### Dari PC (Android Studio)
Open folder ini, tunggu sync, lalu Run. Atau `gradle assembleDebug` dengan Gradle 8.9 dan JDK 17.

## Setelah dipasang
1. Home: nyalakan toggle Island dan izinkan "Tampil di atas aplikasi lain".
2. Notifications: beri akses notifikasi, lalu pilih aplikasi.
   Di Android 13 ke atas, APK dari luar Play Store membuat tombol akses notifikasi berwarna abu-abu. Buka Info aplikasi, ketuk menu titik tiga, pilih "Izinkan setelan terbatas", lalu ulangi.
3. Customize: geser posisi sampai island pas dengan punch-hole kamera.
4. Settings, Pengaturan baterai: set SAMBA ke "Tanpa pembatasan" agar sistem tidak mematikan island.

## Catatan
- Mengetuk Notification Island membuka aplikasi asalnya. Sebagian versi atau OEM Android membatasi peluncuran dari overlay.
- Kode belum pernah dibangun di lingkungan pembuatnya. Status lengkap ada di delivery-gate.md. Jika build gagal, kirim log error-nya.

## Struktur kode
- `SambaStore.kt`: konfigurasi (StateFlow dan penyimpanan lokal)
- `IslandBus.kt`: jalur data antar komponen dan model kondisi island
- `IslandOverlay.kt`: tampilan island (Compose) dan warna
- `IslandService.kt`: foreground service untuk overlay, baterai, media
- `SambaNotificationListener.kt`: pembaca notifikasi (setelah akses diberikan)
- `MediaWatcher.kt`: pemantau sesi media
- `AppIcons.kt`: cache ikon aplikasi
- `MainActivity.kt`: halaman aplikasi

## Fase berikutnya
- Fase 3: Theme Studio, preset, Gaming Mode, penyesuaian notch otomatis, Timer dan Stopwatch.
- Fase 4: uji lintas perangkat, baterai, aksesibilitas, rilis.

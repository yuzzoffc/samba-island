# SAMBA — Dynamic Island for Android

Fase 2 (Smart Island) · Kotlin + Jetpack Compose · minSdk 26 · targetSdk 35

## Isi Fase 2
- Notification Island: pesan dari aplikasi pilihan (bawaan WhatsApp, Telegram, Instagram; tambah aplikasi lain di halaman Notifications). Ketuk island untuk membuka aplikasinya.
- Music Island: judul, artis, cover, animasi audio, tombol sebelumnya/putar/berikutnya, dan progres. Ketuk island musik untuk expand.
- Charging Island: persentase baterai dan animasi saat charger dicolok.
- Empat halaman: Home (pratinjau + toggle), Customize, Notifications, Settings.
- Fase 1 tetap ada: overlay, posisi/ukuran, izin, toggle aktif/nonaktif.

## Privasi
- Tanpa izin INTERNET, jadi tidak ada data yang bisa keluar dari ponsel.
- Akses notifikasi diberikan sendiri oleh pengguna dan bisa dicabut kapan saja.
- Hanya aplikasi yang dipilih yang diteruskan ke island. Isi notifikasi tidak disimpan.
- Isi pesan bisa disembunyikan saat layar terkunci.

## Cara mendapatkan APK
### Dari HP, tanpa PC (GitHub Actions)
1. Buat repositori GitHub baru.
2. Add file → Upload files: unggah `samba-v0.2.0.zip` dan `build-apk.yml` (tanpa diekstrak).
3. Buka `build-apk.yml` → ikon pensil → ubah nama file menjadi `.github/workflows/build-apk.yml` → Commit.
4. Tab Actions: tunggu build selesai (sekitar 6–10 menit pertama).
5. Buka Releases → unduh `SAMBA.apk` → pasang.

### Dari PC (Android Studio)
Open folder ini, tunggu sync, lalu Run. Atau `gradle assembleDebug` dengan Gradle 8.9 dan JDK 17.

## Setelah dipasang
1. Home: nyalakan toggle Island, izinkan "Tampil di atas aplikasi lain".
2. Notifications: beri akses notifikasi, lalu pilih aplikasi.
   Di Android 13+, APK yang dipasang di luar Play Store membuat tombol akses notifikasi abu-abu. Buka Info aplikasi → menu ⋮ → "Izinkan setelan terbatas", lalu ulangi.
3. Customize: geser posisi sampai island pas dengan punch-hole kamera.
4. Settings → Pengaturan baterai: set SAMBA ke "Tanpa pembatasan" agar sistem tidak mematikan island.

## Catatan
- Mengetuk Notification Island membuka aplikasi asalnya. Sebagian versi/OEM Android membatasi peluncuran dari overlay.
- Kode belum pernah dicompile di lingkungan pembuatnya. Jika build gagal, kirim log error-nya.

## Struktur kode
- `SambaStore.kt` — konfigurasi (StateFlow + penyimpanan lokal)
- `IslandBus.kt` — jalur data antar komponen (event, media, baterai) dan model mode island
- `IslandOverlay.kt` — tampilan island (Compose) semua mode
- `IslandService.kt` — foreground service: overlay, baterai, media
- `SambaNotificationListener.kt` — pembaca notifikasi (setelah akses diberikan)
- `MediaWatcher.kt` — pemantau sesi media
- `AppIcons.kt` — cache ikon aplikasi
- `MainActivity.kt` — halaman aplikasi

## Fase berikutnya
- Fase 3: Theme Studio, preset, Gaming Mode, penyesuaian notch otomatis, Timer & Stopwatch.
- Fase 4: uji lintas perangkat, baterai, aksesibilitas, rilis.

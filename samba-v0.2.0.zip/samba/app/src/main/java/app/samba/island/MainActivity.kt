package app.samba.island

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.service.notification.NotificationListenerService
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {

    private var refresh by mutableIntStateOf(0)
    private var pendingEnable = false

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        SambaStore.load(this)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = SambaColors.Neon,
                    onPrimary = SambaColors.Ink,
                    secondary = SambaColors.Violet,
                    tertiary = SambaColors.Mint,
                    background = SambaColors.Ink,
                    surface = SambaColors.Ink,
                    onBackground = Color.White,
                    onSurface = Color.White,
                ),
            ) {
                SambaApp(
                    refresh = refresh,
                    onToggle = { on -> toggleIsland(on) },
                    onOverlaySettings = { openOverlaySettings() },
                    onAccessSettings = { openNotificationAccess() },
                    onAppSettings = { openAppSettings() },
                    onBatterySettings = { openBatterySettings() },
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refresh++
        val canDraw = Settings.canDrawOverlays(this)

        // Pengguna baru kembali dari layar izin setelah menekan toggle.
        if (pendingEnable) {
            pendingEnable = false
            if (canDraw) {
                toggleIsland(true)
                return
            }
        }
        // Jaga island tetap sinkron dengan toggle.
        if (SambaStore.config.value.enabled) {
            if (canDraw) {
                ContextCompat.startForegroundService(this, Intent(this, IslandService::class.java))
            } else {
                SambaStore.update(this) { it.copy(enabled = false) }
            }
        }
        // Jika akses notifikasi sudah ada tapi listener belum tersambung, minta sistem menyambungkan ulang.
        val hasAccess = NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
        if (hasAccess && !IslandBus.listenerConnected) {
            try {
                NotificationListenerService.requestRebind(
                    ComponentName(this, SambaNotificationListener::class.java)
                )
            } catch (e: Exception) {
                // Beberapa perangkat menolak. Tidak fatal.
            }
        }
    }

    private fun toggleIsland(on: Boolean) {
        val service = Intent(this, IslandService::class.java)
        if (!on) {
            SambaStore.update(this) { it.copy(enabled = false) }
            stopService(service)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            pendingEnable = true
            openOverlaySettings()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        SambaStore.update(this) { it.copy(enabled = true) }
        ContextCompat.startForegroundService(this, service)
    }

    private fun openOverlaySettings() {
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    private fun openNotificationAccess() {
        try {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        } catch (e: Exception) {
            openAppSettings()
        }
    }

    private fun openBatterySettings() {
        try {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        } catch (e: Exception) {
            openAppSettings()
        }
    }

    private fun openAppSettings() {
        startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
        )
    }
}

private enum class Page(val label: String) {
    HOME("Home"),
    CUSTOMIZE("Customize"),
    NOTIFICATIONS("Notifications"),
    SETTINGS("Settings"),
}

private class AppEntry(val pkg: String, val label: String)

private val DemoMedia = MediaInfo(
    title = "Judul lagu",
    artist = "Nama artis",
    art = null,
    playing = true,
    duration = 215_000L,
)

private val DemoNotification = NotificationEvent(
    id = -1L,
    appName = "Pesan",
    title = "Rizky",
    text = "Oke bro, ntar kabarin lagi ya!",
    icon = null,
    intent = null,
)

private val PreviewLabels = listOf("Compact", "Musik", "Notifikasi", "Charging")

private fun loadLaunchableApps(context: Context, allowed: Set<String>): List<AppEntry> {
    val pm = context.packageManager
    val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(launcher, 0)
        .map { AppEntry(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
        .filter { it.pkg != context.packageName }
        .distinctBy { it.pkg }
        .sortedWith(
            compareByDescending<AppEntry> { it.pkg in allowed }.thenBy { it.label.lowercase() }
        )
}

@Composable
private fun SambaApp(
    refresh: Int,
    onToggle: (Boolean) -> Unit,
    onOverlaySettings: () -> Unit,
    onAccessSettings: () -> Unit,
    onAppSettings: () -> Unit,
    onBatterySettings: () -> Unit,
) {
    val context = LocalContext.current
    val cfg by SambaStore.config.collectAsState()
    val canOverlay = remember(refresh) { Settings.canDrawOverlays(context) }
    val hasAccess = remember(refresh) {
        NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)
    }
    var page by rememberSaveable { mutableStateOf(Page.HOME) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SambaColors.Ink)
            .statusBarsPadding(),
    ) {
        Box(Modifier.weight(1f)) {
            when (page) {
                Page.HOME -> HomeScreen(cfg, canOverlay, onToggle, onOverlaySettings)
                Page.CUSTOMIZE -> CustomizeScreen(cfg)
                Page.NOTIFICATIONS ->
                    NotificationsScreen(cfg, hasAccess, refresh, onAccessSettings, onAppSettings)
                Page.SETTINGS -> SettingsScreen(
                    canOverlay, hasAccess, onOverlaySettings, onAccessSettings, onAppSettings, onBatterySettings
                )
            }
        }
        HorizontalDivider(color = SambaColors.Line)
        BottomBar(page) { page = it }
    }
}

@Composable
private fun BottomBar(selected: Page, onSelect: (Page) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(SambaColors.Ink)
            .navigationBarsPadding(),
    ) {
        for (p in Page.values()) {
            val isSelected = p == selected
            Column(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onSelect(p) }
                    .padding(top = 8.dp, bottom = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box(
                    Modifier
                        .width(22.dp)
                        .height(3.dp)
                        .clip(CircleShape)
                        .background(if (isSelected) SambaColors.Neon else Color.Transparent)
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    p.label,
                    color = if (isSelected) Color.White else SambaColors.Muted,
                    fontSize = 12.sp,
                    fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                )
            }
        }
    }
}

@Composable
private fun HomeScreen(
    cfg: IslandConfig,
    canOverlay: Boolean,
    onToggle: (Boolean) -> Unit,
    onOverlaySettings: () -> Unit,
) {
    var kind by remember { mutableIntStateOf(0) }
    var open by remember { mutableStateOf(false) }
    val mode: IslandMode = when (kind) {
        1 -> if (open) IslandMode.MusicOpen(DemoMedia) else IslandMode.MusicMini(DemoMedia)
        2 -> IslandMode.Notification(DemoNotification)
        3 -> IslandMode.Charging
        else -> if (open) IslandMode.Peek else IslandMode.Compact
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
    ) {
        Column {
            Text(
                "SAMBA",
                color = Color.White,
                fontSize = 34.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 6.sp,
            )
            Text("Dynamic Island for Android", color = SambaColors.Muted, fontSize = 14.sp)
        }

        // Pratinjau: elemen utama layar ini. Pilih jenis island di bawahnya.
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(206.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(Brush.verticalGradient(listOf(Color(0xFF1C3FB0), Color(0xFF0A0F2E)))),
            contentAlignment = Alignment.TopCenter,
        ) {
            IslandView(
                mode = mode,
                cfg = cfg,
                modifier = Modifier.padding(top = 14.dp),
                fixedProgress = 0.4f,
                onTap = {
                    if (kind == 0 || kind == 1) open = !open
                },
            )
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                PreviewLabels.forEachIndexed { i, label ->
                    val selected = i == kind
                    Text(
                        label,
                        color = if (selected) SambaColors.Ink else Color(0xCCFFFFFF),
                        fontSize = 12.sp,
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(if (selected) SambaColors.Neon else Color(0x26FFFFFF))
                            .clickable {
                                kind = i
                                open = false
                            }
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                    )
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Island", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    if (cfg.enabled) "Aktif di atas layar" else "Nonaktif",
                    color = SambaColors.Muted,
                    fontSize = 13.sp,
                )
            }
            Switch(
                checked = cfg.enabled,
                onCheckedChange = onToggle,
                colors = sambaSwitchColors(),
            )
        }

        if (!canOverlay) {
            Notice(
                title = "Izin belum aktif",
                body = "Tanpa izin 'Tampil di atas aplikasi lain', island tidak bisa muncul di layar.",
                action = "Aktifkan izin",
                onAction = onOverlaySettings,
            )
        }
    }
}

@Composable
private fun CustomizeScreen(cfg: IslandConfig) {
    val context = LocalContext.current
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
    ) {
        SectionTitle("Posisi dan ukuran")
        SliderRow("Posisi vertikal", cfg.offsetY, 0..80, "dp") { v ->
            SambaStore.update(context) { it.copy(offsetY = v) }
        }
        SliderRow("Posisi horizontal", cfg.offsetX, -150..150, "dp") { v ->
            SambaStore.update(context) { it.copy(offsetX = v) }
        }
        SliderRow("Lebar", cfg.width, 80..220, "dp") { v ->
            SambaStore.update(context) { it.copy(width = v) }
        }
        SliderRow("Tinggi", cfg.height, 24..52, "dp") { v ->
            SambaStore.update(context) { it.copy(height = v) }
        }
        TextButton(
            onClick = {
                val d = IslandConfig()
                SambaStore.update(context) { cur ->
                    cur.copy(offsetX = d.offsetX, offsetY = d.offsetY, width = d.width, height = d.height)
                }
            },
        ) {
            Text("Kembalikan ke bawaan", color = SambaColors.Neon)
        }

        Spacer(Modifier.height(12.dp))
        HorizontalDivider(color = SambaColors.Line)
        Spacer(Modifier.height(16.dp))

        SectionTitle("Tampil di island")
        Spacer(Modifier.height(4.dp))
        SwitchRow("Notifikasi", "Pesan dari aplikasi yang kamu pilih.", cfg.notifEnabled) { on ->
            SambaStore.update(context) { it.copy(notifEnabled = on) }
        }
        SwitchRow("Musik", "Judul lagu, kontrol putar, dan animasi audio.", cfg.musicEnabled) { on ->
            SambaStore.update(context) { it.copy(musicEnabled = on) }
        }
        SwitchRow("Pengisian daya", "Persentase baterai saat charger dicolok.", cfg.chargingEnabled) { on ->
            SambaStore.update(context) { it.copy(chargingEnabled = on) }
        }
    }
}

@Composable
private fun NotificationsScreen(
    cfg: IslandConfig,
    hasAccess: Boolean,
    refresh: Int,
    onAccessSettings: () -> Unit,
    onAppSettings: () -> Unit,
) {
    val context = LocalContext.current
    val apps by produceState<List<AppEntry>>(emptyList(), refresh) {
        value = withContext(Dispatchers.Default) {
            loadLaunchableApps(context, SambaStore.config.value.allowedApps)
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
    ) {
        item {
            Column {
                SectionTitle("Notifications")
                Spacer(Modifier.height(4.dp))
                Text(
                    "Pilih aplikasi yang boleh muncul di island. Isi notifikasi hanya diproses di ponselmu.",
                    color = SambaColors.Muted,
                    fontSize = 13.sp,
                    lineHeight = 19.sp,
                )
                Spacer(Modifier.height(16.dp))
            }
        }

        if (!hasAccess) {
            item {
                Column {
                    Notice(
                        title = "Akses notifikasi belum aktif",
                        body = "Island butuh akses notifikasi untuk menampilkan pesan dan membaca musik yang sedang diputar.",
                        action = "Beri akses notifikasi",
                        onAction = onAccessSettings,
                    )
                    if (Build.VERSION.SDK_INT >= 33) {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Jika tombol akses berwarna abu-abu: buka Info aplikasi, ketuk menu titik tiga di pojok kanan atas, lalu pilih Izinkan setelan terbatas.",
                            color = SambaColors.Muted,
                            fontSize = 12.sp,
                            lineHeight = 17.sp,
                        )
                        TextButton(onClick = onAppSettings) {
                            Text("Buka info aplikasi", color = SambaColors.Neon)
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                }
            }
        }

        item {
            val context2 = LocalContext.current
            Column {
                SwitchRow("Tampilkan notifikasi di island", null, cfg.notifEnabled) { on ->
                    SambaStore.update(context2) { it.copy(notifEnabled = on) }
                }
                SwitchRow(
                    "Sembunyikan isi pesan saat layar terkunci",
                    "Island hanya menampilkan nama aplikasi dan tulisan Pesan baru.",
                    cfg.hideOnLock,
                ) { on ->
                    SambaStore.update(context2) { it.copy(hideOnLock = on) }
                }
                SliderRow("Lama tampil", cfg.notifSeconds, 2..10, "detik") { v ->
                    SambaStore.update(context2) { it.copy(notifSeconds = v) }
                }
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = {
                        IslandBus.show(
                            NotificationEvent(
                                id = IslandBus.nextId(),
                                appName = "SAMBA",
                                title = "Notifikasi uji",
                                text = "Island menerima notifikasi seperti ini.",
                                icon = null,
                                intent = null,
                            )
                        )
                    },
                    enabled = cfg.enabled,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = SambaColors.Neon,
                        contentColor = SambaColors.Ink,
                    ),
                ) {
                    Text("Kirim notifikasi uji")
                }
                if (!cfg.enabled) {
                    Spacer(Modifier.height(4.dp))
                    Text("Nyalakan Island di Home dulu.", color = SambaColors.Muted, fontSize = 12.sp)
                }
                Spacer(Modifier.height(16.dp))
                HorizontalDivider(color = SambaColors.Line)
                Spacer(Modifier.height(16.dp))
                SectionTitle("Aplikasi yang boleh tampil")
                Spacer(Modifier.height(4.dp))
            }
        }

        items(apps, key = { it.pkg }) { app ->
            AppRow(
                app = app,
                checked = app.pkg in cfg.allowedApps,
                onChange = { on ->
                    SambaStore.update(context) { c ->
                        c.copy(allowedApps = if (on) c.allowedApps + app.pkg else c.allowedApps - app.pkg)
                    }
                },
            )
        }
    }
}

@Composable
private fun SettingsScreen(
    canOverlay: Boolean,
    hasAccess: Boolean,
    onOverlaySettings: () -> Unit,
    onAccessSettings: () -> Unit,
    onAppSettings: () -> Unit,
    onBatterySettings: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
    ) {
        SectionTitle("Izin")
        Spacer(Modifier.height(4.dp))
        StatusRow("Tampil di atas aplikasi lain", canOverlay, "Buka", onOverlaySettings)
        StatusRow("Akses notifikasi", hasAccess, "Buka", onAccessSettings)
        TextButton(onClick = onBatterySettings) {
            Text("Pengaturan baterai (agar island tidak dimatikan sistem)", color = SambaColors.Neon, fontSize = 13.sp)
        }
        TextButton(onClick = onAppSettings) {
            Text("Info aplikasi", color = SambaColors.Neon, fontSize = 13.sp)
        }

        Spacer(Modifier.height(12.dp))
        HorizontalDivider(color = SambaColors.Line)
        Spacer(Modifier.height(16.dp))

        SectionTitle("Privasi")
        Spacer(Modifier.height(8.dp))
        Text(
            "SAMBA tidak punya izin internet, jadi tidak ada data yang bisa keluar dari ponselmu.\n\n" +
                "Isi notifikasi hanya diproses di memori selama island tampil dan tidak disimpan.\n\n" +
                "Hanya aplikasi yang kamu pilih di halaman Notifications yang bisa muncul. Isi pesan bisa disembunyikan saat layar terkunci.\n\n" +
                "Untuk mencabut akses, ketuk Buka di baris izin di atas dan matikan SAMBA.",
            color = SambaColors.Muted,
            fontSize = 13.sp,
            lineHeight = 20.sp,
        )

        Spacer(Modifier.height(16.dp))
        HorizontalDivider(color = SambaColors.Line)
        Spacer(Modifier.height(16.dp))

        SectionTitle("Cara mengaktifkan")
        Spacer(Modifier.height(8.dp))
        Text(
            "1. Di Home, nyalakan toggle Island dan izinkan 'Tampil di atas aplikasi lain'.\n" +
                "2. Di Notifications, beri akses notifikasi lalu pilih aplikasinya.\n" +
                "3. Di Customize, geser posisi sampai island pas dengan punch-hole kamera.",
            color = SambaColors.Muted,
            fontSize = 13.sp,
            lineHeight = 20.sp,
        )

        Spacer(Modifier.height(24.dp))
        Text("Versi 0.2.0 (Fase 2)", color = SambaColors.Muted, fontSize = 12.sp)
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
}

@Composable
private fun Notice(title: String, body: String, action: String, onAction: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SambaColors.Violet, RoundedCornerShape(16.dp))
            .padding(16.dp),
    ) {
        Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Text(body, color = SambaColors.Muted, fontSize = 13.sp, lineHeight = 19.sp)
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = onAction,
            colors = ButtonDefaults.buttonColors(
                containerColor = SambaColors.Neon,
                contentColor = SambaColors.Ink,
            ),
        ) {
            Text(action)
        }
    }
}

@Composable
private fun sambaSwitchColors(): SwitchColors =
    SwitchDefaults.colors(
        checkedThumbColor = SambaColors.Ink,
        checkedTrackColor = SambaColors.Neon,
        uncheckedThumbColor = SambaColors.Muted,
        uncheckedTrackColor = Color(0xFF1A1D28),
    )

@Composable
private fun SwitchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 15.sp)
            if (subtitle != null) {
                Text(subtitle, color = SambaColors.Muted, fontSize = 12.sp, lineHeight = 17.sp)
            }
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange, colors = sambaSwitchColors())
    }
}

@Composable
private fun SliderRow(label: String, value: Int, range: IntRange, unit: String, onChange: (Int) -> Unit) {
    Column(Modifier.padding(top = 10.dp)) {
        Row {
            Text(label, color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Text("$value $unit", color = SambaColors.Muted, fontSize = 13.sp)
        }
        Slider(
            value = value.toFloat(),
            onValueChange = { onChange(it.toInt()) },
            valueRange = range.first.toFloat()..range.last.toFloat(),
            colors = SliderDefaults.colors(
                thumbColor = SambaColors.Neon,
                activeTrackColor = SambaColors.Neon,
                inactiveTrackColor = Color(0xFF262A38),
            ),
        )
    }
}

@Composable
private fun StatusRow(title: String, ok: Boolean, action: String, onAction: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 15.sp)
            Text(
                if (ok) "Aktif" else "Belum aktif",
                color = if (ok) SambaColors.Mint else SambaColors.Violet,
                fontSize = 12.sp,
            )
        }
        TextButton(onClick = onAction) {
            Text(action, color = SambaColors.Neon)
        }
    }
}

@Composable
private fun AppRow(app: AppEntry, checked: Boolean, onChange: (Boolean) -> Unit) {
    val context = LocalContext.current
    val icon by produceState<ImageBitmap?>(null, app.pkg) {
        value = withContext(Dispatchers.IO) { AppIcons.get(context, app.pkg) }
    }
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        val img = icon
        if (img != null) {
            Image(
                bitmap = img,
                contentDescription = null,
                modifier = Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)),
            )
        } else {
            Box(
                Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF1A1D28))
            )
        }
        Spacer(Modifier.width(12.dp))
        Text(
            app.label,
            color = Color.White,
            fontSize = 15.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
        Switch(checked = checked, onCheckedChange = onChange, colors = sambaSwitchColors())
    }
}

package app.samba.island

import android.graphics.Bitmap
import android.os.SystemClock
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

object SambaColors {
    val Ink = Color(0xFF08090D)
    val Neon = Color(0xFF42D9FF)
    val Violet = Color(0xFF8C63FF)
    val Mint = Color(0xFF48E6C1)
    val Muted = Color(0xFF8D93A6)
    val Line = Color(0xFF1E2230)
}

/**
 * Island di dalam overlay. Dipasang oleh IslandService.
 * Prioritas: notifikasi > pengisian daya > musik > intip (Peek) > compact.
 */
@Composable
fun IslandHost() {
    val context = LocalContext.current
    val cfg by SambaStore.config.collectAsState()
    val event by IslandBus.event.collectAsState()
    val mediaRaw by IslandBus.media.collectAsState()
    var peek by remember { mutableStateOf(false) }
    var musicOpen by remember { mutableStateOf(false) }

    val media = if (cfg.musicEnabled) mediaRaw else null
    val current = event

    // Kejadian sementara hilang sendiri setelah durasinya habis.
    LaunchedEffect(current?.id) {
        val ev = current ?: return@LaunchedEffect
        val seconds = if (ev is NotificationEvent) cfg.notifSeconds else 3
        delay(seconds * 1000L)
        IslandBus.clear(ev.id)
    }
    LaunchedEffect(peek) {
        if (peek) {
            delay(4000)
            peek = false
        }
    }
    LaunchedEffect(musicOpen) {
        if (musicOpen) {
            delay(7000)
            musicOpen = false
        }
    }
    LaunchedEffect(media == null) {
        if (media == null) musicOpen = false
    }

    val mode: IslandMode = when {
        current is NotificationEvent -> IslandMode.Notification(current)
        current is ChargingEvent -> IslandMode.Charging
        media != null && musicOpen -> IslandMode.MusicOpen(media)
        media != null -> IslandMode.MusicMini(media)
        peek -> IslandMode.Peek
        else -> IslandMode.Compact
    }

    IslandView(
        mode = mode,
        cfg = cfg,
        onTap = {
            when (mode) {
                is IslandMode.Notification -> {
                    IslandBus.open(context, mode.event)
                    IslandBus.clear(mode.event.id)
                }
                IslandMode.Charging -> current?.let { IslandBus.clear(it.id) }
                is IslandMode.MusicMini -> musicOpen = true
                is IslandMode.MusicOpen -> musicOpen = false
                IslandMode.Peek -> peek = false
                IslandMode.Compact -> peek = true
            }
        },
        onPlayPause = { IslandBus.playPause() },
        onNext = { IslandBus.next() },
        onPrevious = { IslandBus.previous() },
    )
}

/**
 * Tampilan island yang murni presentasi (dipakai overlay dan pratinjau di aplikasi).
 * Ukuran dianimasikan dengan spring, isi berganti dengan crossfade.
 */
@Composable
fun IslandView(
    mode: IslandMode,
    cfg: IslandConfig,
    modifier: Modifier = Modifier,
    fixedProgress: Float? = null,
    onTap: () -> Unit = {},
    onPlayPause: () -> Unit = {},
    onNext: () -> Unit = {},
    onPrevious: () -> Unit = {},
) {
    val screenW = LocalConfiguration.current.screenWidthDp
    val maxW = minOf(screenW - 24, 340).dp
    val compactW = cfg.width.dp
    val compactH = cfg.height.dp

    val target: Pair<Dp, Dp> = when (mode) {
        IslandMode.Compact -> compactW to compactH
        IslandMode.Peek -> minOf(maxW, 230.dp) to 52.dp
        IslandMode.Charging -> maxOf(compactW + 40.dp, 150.dp) to compactH
        is IslandMode.MusicMini -> (compactW + 64.dp) to compactH
        is IslandMode.MusicOpen -> maxW to 138.dp
        is IslandMode.Notification -> maxW to 72.dp
    }

    val spec = spring<Dp>(dampingRatio = 0.74f, stiffness = 360f)
    val w by animateDpAsState(target.first, spec, label = "islandW")
    val h by animateDpAsState(target.second, spec, label = "islandH")

    val borderBrush = when (mode) {
        is IslandMode.Notification ->
            Brush.horizontalGradient(listOf(SambaColors.Mint, SambaColors.Neon))
        IslandMode.Charging ->
            Brush.horizontalGradient(listOf(SambaColors.Mint, SambaColors.Mint))
        else ->
            Brush.horizontalGradient(listOf(SambaColors.Neon, SambaColors.Violet))
    }
    val shape = RoundedCornerShape(minOf(h / 2, 34.dp))

    Box(
        modifier = modifier
            .size(w, h)
            .clip(shape)
            .background(SambaColors.Ink)
            .border(1.dp, borderBrush, shape)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onTap,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Crossfade(
            targetState = mode,
            modifier = Modifier.fillMaxSize(),
            animationSpec = tween(180),
            label = "islandContent",
        ) { m ->
            when (m) {
                IslandMode.Compact -> CompactContent(compactH)
                IslandMode.Peek -> PeekContent()
                IslandMode.Charging -> ChargingContent()
                is IslandMode.MusicMini -> MusicMiniContent(m.media, compactH)
                is IslandMode.MusicOpen ->
                    MusicOpenContent(m.media, fixedProgress, onPlayPause, onNext, onPrevious)
                is IslandMode.Notification -> NotificationContent(m.event)
            }
        }
    }
}

@Composable
private fun CompactContent(height: Dp) {
    val dot = height * 0.4f
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(dot).clip(CircleShape).background(SambaColors.Neon))
            Spacer(Modifier.width(height * 0.18f))
            Box(
                Modifier
                    .size(width = dot * 1.9f, height = dot * 0.55f)
                    .clip(CircleShape)
                    .background(SambaColors.Violet)
            )
        }
    }
}

@Composable
private fun PeekContent() {
    val battery by IslandBus.battery.collectAsState()
    Row(
        modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(SambaColors.Neon, SambaColors.Violet)))
        )
        Spacer(Modifier.width(12.dp))
        Column {
            Text("SAMBA", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text(
                if (battery.level >= 0) "Island aktif, baterai ${battery.level}%" else "Island aktif",
                color = SambaColors.Muted,
                fontSize = 12.sp,
                maxLines = 1,
            )
        }
    }
}

@Composable
private fun MusicMiniContent(media: MediaInfo, height: Dp) {
    Row(
        modifier = Modifier.fillMaxSize().padding(horizontal = 7.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AlbumArt(media.art, maxOf(height - 10.dp, 14.dp))
        Waveform(media.playing, Modifier.size(width = 22.dp, height = 14.dp))
    }
}

@Composable
private fun MusicOpenContent(
    media: MediaInfo,
    fixedProgress: Float?,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AlbumArt(media.art, 44.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    media.title,
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    media.artist,
                    color = SambaColors.Muted,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Spacer(Modifier.width(8.dp))
            Waveform(media.playing, Modifier.size(width = 26.dp, height = 18.dp))
        }
        MusicProgress(media, fixedProgress)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TransportButton(Transport.Previous, onPrevious, 40.dp)
            Spacer(Modifier.width(18.dp))
            TransportButton(if (media.playing) Transport.Pause else Transport.Play, onPlayPause, 44.dp)
            Spacer(Modifier.width(18.dp))
            TransportButton(Transport.Next, onNext, 40.dp)
        }
    }
}

@Composable
private fun MusicProgress(media: MediaInfo, fixed: Float?) {
    val progress by IslandBus.progress.collectAsState()
    var now by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }

    // Memperbarui bilah progres hanya selama lagu diputar dan island musik terbuka.
    LaunchedEffect(media.playing, media.duration, fixed) {
        while (media.playing && fixed == null) {
            now = SystemClock.elapsedRealtime()
            delay(500)
        }
    }

    val fraction: Float = when {
        fixed != null -> fixed
        media.duration <= 0L -> 0f
        else -> {
            val position = if (media.playing) {
                progress.position + ((now - progress.updateTime) * progress.speed).toLong()
            } else {
                progress.position
            }
            (position.toFloat() / media.duration).coerceIn(0f, 1f)
        }
    }

    Box(
        Modifier
            .fillMaxWidth()
            .height(3.dp)
            .clip(CircleShape)
            .background(Color(0xFF262A38))
    ) {
        Box(
            Modifier
                .fillMaxWidth(fraction)
                .fillMaxHeight()
                .background(Brush.horizontalGradient(listOf(SambaColors.Neon, SambaColors.Violet)))
        )
    }
}

@Composable
private fun NotificationContent(e: NotificationEvent) {
    Row(
        modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AppIcon(e.icon, e.appName, 40.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                e.title,
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                e.text,
                color = SambaColors.Muted,
                fontSize = 12.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun ChargingContent() {
    val battery by IslandBus.battery.collectAsState()
    Row(
        modifier = Modifier.fillMaxSize(),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        BatteryGlyph(battery.level, Modifier.size(width = 22.dp, height = 12.dp))
        Spacer(Modifier.width(8.dp))
        Text(
            if (battery.level >= 0) "${battery.level}%" else "--",
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
        )
        Spacer(Modifier.width(6.dp))
        Bolt(Modifier.size(width = 10.dp, height = 14.dp))
    }
}

@Composable
private fun AlbumArt(art: Bitmap?, boxSize: Dp) {
    val shape = RoundedCornerShape(boxSize * 0.28f)
    val image = remember(art) { art?.asImageBitmap() }
    if (image != null) {
        Image(
            bitmap = image,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(boxSize).clip(shape),
        )
    } else {
        Box(
            Modifier
                .size(boxSize)
                .clip(shape)
                .background(Brush.linearGradient(listOf(SambaColors.Violet, SambaColors.Neon))),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                "♪",
                color = SambaColors.Ink,
                fontSize = (boxSize.value * 0.5f).sp,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}

@Composable
private fun AppIcon(icon: ImageBitmap?, name: String, boxSize: Dp) {
    val shape = RoundedCornerShape(boxSize * 0.28f)
    if (icon != null) {
        Image(
            bitmap = icon,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(boxSize).clip(shape),
        )
    } else {
        Box(
            Modifier.size(boxSize).clip(shape).background(SambaColors.Mint),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                name.take(1).uppercase(),
                color = SambaColors.Ink,
                fontSize = (boxSize.value * 0.46f).sp,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}

/** Animasi audio: hanya bergerak saat musik diputar. */
@Composable
private fun Waveform(playing: Boolean, modifier: Modifier = Modifier) {
    val brush = remember { Brush.horizontalGradient(listOf(SambaColors.Neon, SambaColors.Violet)) }
    if (playing) {
        val transition = rememberInfiniteTransition(label = "wave")
        val phase by transition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable<Float>(tween(1000, easing = LinearEasing)),
            label = "wavePhase",
        )
        WaveBars(brush, modifier) { phase }
    } else {
        WaveBars(brush, modifier) { -1f }
    }
}

@Composable
private fun WaveBars(brush: Brush, modifier: Modifier, phase: () -> Float) {
    Canvas(modifier) {
        val p = phase()
        val bars = 4
        val barW = size.width / (bars * 2 - 1)
        for (i in 0 until bars) {
            val level = if (p < 0f) {
                0.3f
            } else {
                0.3f + 0.7f * abs(sin((p + i * 0.18f) * 2f * PI.toFloat()))
            }
            val barH = size.height * level
            drawRoundRect(
                brush = brush,
                topLeft = Offset(i * 2 * barW, (size.height - barH) / 2f),
                size = Size(barW, barH),
                cornerRadius = CornerRadius(barW / 2f, barW / 2f),
            )
        }
    }
}

@Composable
private fun BatteryGlyph(level: Int, modifier: Modifier) {
    val pulse = rememberInfiniteTransition(label = "charge")
    val alpha by pulse.animateFloat(
        initialValue = 0.55f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable<Float>(tween(700), RepeatMode.Reverse),
        label = "chargeAlpha",
    )
    Canvas(modifier) {
        val stroke = 1.5.dp.toPx()
        val nub = 2.dp.toPx()
        val bodyW = size.width - nub
        drawRoundRect(
            color = SambaColors.Mint,
            topLeft = Offset(stroke / 2f, stroke / 2f),
            size = Size(bodyW - stroke, size.height - stroke),
            cornerRadius = CornerRadius(3.dp.toPx()),
            style = Stroke(width = stroke),
        )
        val fraction = level.coerceIn(0, 100) / 100f
        drawRoundRect(
            color = SambaColors.Mint.copy(alpha = alpha),
            topLeft = Offset(stroke * 2f, stroke * 2f),
            size = Size((bodyW - stroke * 4f) * fraction, size.height - stroke * 4f),
            cornerRadius = CornerRadius(1.5.dp.toPx()),
        )
        drawRoundRect(
            color = SambaColors.Mint,
            topLeft = Offset(bodyW, size.height * 0.3f),
            size = Size(nub, size.height * 0.4f),
            cornerRadius = CornerRadius(1.dp.toPx()),
        )
    }
}

@Composable
private fun Bolt(modifier: Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val path = Path().apply {
            moveTo(w * 0.60f, 0f)
            lineTo(w * 0.10f, h * 0.58f)
            lineTo(w * 0.46f, h * 0.58f)
            lineTo(w * 0.34f, h)
            lineTo(w * 0.92f, h * 0.38f)
            lineTo(w * 0.54f, h * 0.38f)
            close()
        }
        drawPath(path, SambaColors.Mint)
    }
}

private enum class Transport { Play, Pause, Next, Previous }

@Composable
private fun TransportButton(kind: Transport, onClick: () -> Unit, boxSize: Dp) {
    Box(
        modifier = Modifier
            .size(boxSize)
            .clip(CircleShape)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        TransportIcon(kind, Modifier.size(boxSize * 0.5f))
    }
}

@Composable
private fun TransportIcon(kind: Transport, modifier: Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val color = Color.White
        when (kind) {
            Transport.Play -> {
                val path = Path().apply {
                    moveTo(w * 0.22f, h * 0.12f)
                    lineTo(w * 0.88f, h * 0.50f)
                    lineTo(w * 0.22f, h * 0.88f)
                    close()
                }
                drawPath(path, color)
            }
            Transport.Pause -> {
                drawRoundRect(color, Offset(w * 0.20f, h * 0.12f), Size(w * 0.22f, h * 0.76f), CornerRadius(w * 0.06f))
                drawRoundRect(color, Offset(w * 0.58f, h * 0.12f), Size(w * 0.22f, h * 0.76f), CornerRadius(w * 0.06f))
            }
            Transport.Next -> {
                val path = Path().apply {
                    moveTo(w * 0.12f, h * 0.15f)
                    lineTo(w * 0.70f, h * 0.50f)
                    lineTo(w * 0.12f, h * 0.85f)
                    close()
                }
                drawPath(path, color)
                drawRoundRect(color, Offset(w * 0.76f, h * 0.15f), Size(w * 0.12f, h * 0.70f), CornerRadius(w * 0.04f))
            }
            Transport.Previous -> {
                val path = Path().apply {
                    moveTo(w * 0.88f, h * 0.15f)
                    lineTo(w * 0.30f, h * 0.50f)
                    lineTo(w * 0.88f, h * 0.85f)
                    close()
                }
                drawPath(path, color)
                drawRoundRect(color, Offset(w * 0.12f, h * 0.15f), Size(w * 0.12f, h * 0.70f), CornerRadius(w * 0.04f))
            }
        }
    }
}
